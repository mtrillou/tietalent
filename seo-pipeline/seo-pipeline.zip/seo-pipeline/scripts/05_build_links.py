#!/usr/bin/env python3
"""
Step 6: Build internal linking graph.
- Hub pages: /remote-jobs, /tech-jobs, /ai-jobs, per-locale
- Hub → job page links
- Job page → related roles (same cluster)
- Cross-locale equivalents
"""

import json
import logging
from pathlib import Path
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)

DATA_DIR = Path(__file__).parent.parent / "data"

HUB_DEFINITIONS = {
    "en": [
        {
            "slug":    "remote-jobs",
            "url":     "/en/jobs/remote-jobs",
            "title":   "Remote Jobs in Europe | TieTalent",
            "h1":      "Remote Jobs",
            "meta":    "Find the best remote jobs across Europe on TieTalent. Browse full-remote and hybrid positions from top companies.",
            "clusters": None,  # all clusters
            "filter":  "remote=true",
        },
        {
            "slug":    "tech-jobs",
            "url":     "/en/jobs/tech-jobs",
            "title":   "Tech Jobs in Europe | TieTalent",
            "h1":      "Tech Jobs",
            "meta":    "Discover tech jobs at innovative companies across Europe. From software engineering to product management — find your next role on TieTalent.",
            "clusters": ["software-engineering", "backend-engineering", "frontend-engineering", "mobile-development", "devops-sre", "data-engineering"],
            "filter":  "category=tech",
        },
        {
            "slug":    "ai-jobs",
            "url":     "/en/jobs/ai-jobs",
            "title":   "AI & Machine Learning Jobs | TieTalent",
            "h1":      "AI & Machine Learning Jobs",
            "meta":    "Explore AI, machine learning, and data science jobs at companies building the future. Find your next AI role on TieTalent.",
            "clusters": ["ai-ml", "data-science", "data-engineering", "nlp", "computer-vision"],
            "filter":  "category=ai",
        },
        {
            "slug":    "startup-jobs",
            "url":     "/en/jobs/startup-jobs",
            "title":   "Startup Jobs in Europe | TieTalent",
            "h1":      "Startup Jobs",
            "meta":    "Join a high-growth startup in Europe. TieTalent connects ambitious professionals with seed-to-Series-C companies hiring now.",
            "clusters": None,
            "filter":  "company_stage=startup",
        },
    ],
    "fr": [
        {
            "slug":    "teletravail",
            "url":     "/fr/jobs/teletravail",
            "title":   "Emplois en télétravail | TieTalent",
            "h1":      "Emplois en télétravail",
            "meta":    "Trouvez les meilleures offres d'emploi en télétravail sur TieTalent. Full remote, hybride — toutes les options disponibles.",
            "clusters": None,
            "filter":  "remote=true",
        },
        {
            "slug":    "emplois-tech",
            "url":     "/fr/jobs/emplois-tech",
            "title":   "Emplois Tech en Europe | TieTalent",
            "h1":      "Emplois Tech",
            "meta":    "Découvrez les meilleures offres tech en Europe sur TieTalent. Développeurs, data scientists, DevOps et plus.",
            "clusters": ["software-engineering", "backend-engineering", "frontend-engineering", "mobile-development", "devops-sre"],
            "filter":  "category=tech",
        },
        {
            "slug":    "emplois-ia",
            "url":     "/fr/jobs/emplois-ia",
            "title":   "Emplois IA & Machine Learning | TieTalent",
            "h1":      "Emplois Intelligence Artificielle",
            "meta":    "Explorez les offres IA, machine learning et data science sur TieTalent. Rejoignez les équipes qui construisent l'avenir.",
            "clusters": ["ai-ml", "data-science"],
            "filter":  "category=ai",
        },
    ],
    "de": [
        {
            "slug":    "remote-stellen",
            "url":     "/de/jobs/remote-stellen",
            "title":   "Remote Jobs in Europa | TieTalent",
            "h1":      "Remote Jobs",
            "meta":    "Finde die besten Remote-Jobs in Europa auf TieTalent. Vollzeit Remote und Hybrid-Positionen von Top-Unternehmen.",
            "clusters": None,
            "filter":  "remote=true",
        },
        {
            "slug":    "tech-jobs",
            "url":     "/de/jobs/tech-jobs",
            "title":   "Tech Jobs in Europa | TieTalent",
            "h1":      "Tech Jobs",
            "meta":    "Entdecke Tech-Stellen bei innovativen Unternehmen in Europa. Software, Data, DevOps und mehr auf TieTalent.",
            "clusters": ["software-engineering", "backend-engineering", "frontend-engineering", "devops-sre"],
            "filter":  "category=tech",
        },
    ],
}

# Cross-locale hub equivalents
HUB_CROSS_LOCALE = {
    "remote": {
        "en": "/en/jobs/remote-jobs",
        "fr": "/fr/jobs/teletravail",
        "de": "/de/jobs/remote-stellen",
    },
    "tech": {
        "en": "/en/jobs/tech-jobs",
        "fr": "/fr/jobs/emplois-tech",
        "de": "/de/jobs/tech-jobs",
    },
}

MAX_RELATED_LINKS = 8   # per job page
MAX_HUB_CHILDREN   = 30  # max links from hub → job pages


def build_linking_graph(rendered_pages: list[dict]) -> dict:
    """
    Returns a dict:
      {
        "hubs": { locale: [hub_def + children_urls] },
        "job_links": { pretty_url: { "related": [...], "hub": hub_url, "alternates": {...} } }
      }
    """
    # Index core pages by cluster + locale
    cluster_locale_pages: dict[tuple, list] = defaultdict(list)
    for p in rendered_pages:
        if p["type"] == "core":
            key = (p["cluster"], p["locale"])
            cluster_locale_pages[key].append(p)

    # Build job page → related roles
    job_links = {}
    for p in rendered_pages:
        if p["type"] != "core":
            continue
        cluster_peers = cluster_locale_pages.get((p["cluster"], p["locale"]), [])
        related = [
            {"url": peer["pretty_url"], "label": peer["content"]["h1"]}
            for peer in cluster_peers
            if peer["pretty_url"] != p["pretty_url"]
        ][:MAX_RELATED_LINKS]

        # Determine parent hub
        hub_url = None
        for hub_key, hub_locales in HUB_CROSS_LOCALE.items():
            if p["locale"] in hub_locales:
                # Simple heuristic: tech cluster → tech hub; remote flag → remote hub
                tech_clusters = {"software-engineering", "backend-engineering", "frontend-engineering", "devops-sre", "mobile-development"}
                ai_clusters   = {"ai-ml", "data-science"}
                if hub_key == "tech" and p["cluster"] in tech_clusters:
                    hub_url = hub_locales[p["locale"]]
                elif hub_key == "remote" and p["remote"]:
                    hub_url = hub_locales[p["locale"]]

        job_links[p["pretty_url"]] = {
            "related":    related,
            "hub_url":    hub_url,
            "alternates": p.get("alternate_urls", {}),
        }

    # Build hub children
    hubs_output = {}
    for locale, hub_list in HUB_DEFINITIONS.items():
        locale_hubs = []
        for hub in hub_list:
            if hub["clusters"] is None:
                # All core pages for this locale
                children = [
                    p for p in rendered_pages
                    if p["type"] == "core" and p["locale"] == locale
                ]
            else:
                children = [
                    p for p in rendered_pages
                    if p["type"] == "core"
                    and p["locale"] == locale
                    and p["cluster"] in hub["clusters"]
                ]
            # Sort by seo_score
            children.sort(key=lambda x: -x["seo_score"])
            child_links = [
                {"url": c["pretty_url"], "label": c["content"]["h1"], "seo_score": c["seo_score"]}
                for c in children[:MAX_HUB_CHILDREN]
            ]
            locale_hubs.append({**hub, "children": child_links})
        hubs_output[locale] = locale_hubs

    return {"hubs": hubs_output, "job_links": job_links}


def main():
    src = DATA_DIR / "rendered_pages.json"
    if not src.exists():
        log.error("Run 04 first!")
        return

    with open(src, encoding="utf-8") as f:
        rendered_pages = json.load(f)

    graph = build_linking_graph(rendered_pages)

    out = DATA_DIR / "linking_graph.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(graph, f, indent=2, ensure_ascii=False)

    log.info(f"✓ linking_graph.json written")
    log.info(f"  Hub pages: {sum(len(v) for v in graph['hubs'].values())}")
    log.info(f"  Job link entries: {len(graph['job_links'])}")


if __name__ == "__main__":
    main()
