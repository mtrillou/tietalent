#!/usr/bin/env python3
"""
10_generate_readme.py — Jobright-style dynamic README.
Creates a public-facing README.md that:
  - Lists top job pages with live links (GitHub traffic → backlinks)
  - Shows trending roles updated hourly by CI
  - Acts as a backlink farm pointing at TieTalent pages
  - Mirrors Jobright's strategy of GitHub as a lightweight SEO amplifier
"""

import json, logging
from pathlib import Path
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)
DATA_DIR  = Path(__file__).parent.parent / "data"
ROOT_DIR  = Path(__file__).parent.parent
BASE_URL  = "https://tietalent.com"

HEADER = """# TieTalent — Job Search Index

> **The best tech, data, and AI jobs in Europe — updated daily.**

[TieTalent](https://tietalent.com) connects software engineers, data scientists, product managers,
and tech professionals with top companies across Switzerland, France, Germany, and remote-first Europe.
Unlike traditional job boards, companies apply to you — not the other way around.

🔍 **[Search all jobs on TieTalent →](https://tietalent.com/en/jobs)**

---
"""

FOOTER = """
---

## About TieTalent

TieTalent is Europe's reverse job platform for tech professionals. Create a free profile and get
discovered by top companies without applying to each opening individually.

- 🇨🇭 Strong in Switzerland (Zurich, Geneva, Lausanne)
- 🇫🇷 Growing in France (Paris)
- 🇩🇪 Active in Germany (Berlin, Munich)
- 🌍 Remote-first roles across Europe

**[Create your free profile →](https://tietalent.com/register)**

---
*Updated automatically every hour by [our SEO pipeline](https://github.com/tietalent/seo-pages).
Last update: {timestamp}*
"""

CLUSTER_EMOJI = {
    "ai-ml": "🤖", "data-science": "📊", "software-engineering": "💻",
    "backend-engineering": "⚙️", "frontend-engineering": "🎨",
    "devops-sre": "🔧", "product-management": "🗺️", "data-engineering": "🏗️",
    "data-analytics": "📈", "sales": "📣", "marketing": "📢",
    "finance": "💰", "cybersecurity": "🔒", "mobile-development": "📱",
    "ux-design": "✏️", "hr-people": "👥", "project-management": "📋",
    "other": "🔎",
}


def generate_readme(top30: list[dict], tier1: list[dict]) -> str:
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

    # Group top30 by cluster
    by_cluster: dict[str, list] = {}
    for p in top30:
        by_cluster.setdefault(p["cluster"], []).append(p)

    sections = [HEADER]

    # Trending section (top 10 by composite score)
    trending = sorted(top30, key=lambda x: -x.get("composite_score", 0))[:10]
    sections.append("## 🔥 Trending Job Pages This Week\n\n")
    sections.append("| Role | Location | SEO Score |\n")
    sections.append("|------|----------|-----------|\n")
    for p in trending:
        url  = f"{BASE_URL}{p['pretty_url']}"
        loc  = p.get("location_label") or ("Remote" if p.get("remote") else "Europe")
        role = " ".join(w.capitalize() for w in p["slug"].split("-"))
        sc   = p.get("composite_score", "—")
        sections.append(f"| [{role}]({url}) | {loc} | {sc} |\n")
    sections.append("\n")

    # By cluster sections
    sections.append("## Browse by Category\n\n")
    priority_clusters = [
        "ai-ml", "software-engineering", "data-science", "backend-engineering",
        "devops-sre", "product-management", "data-analytics", "frontend-engineering",
    ]
    for cluster in priority_clusters:
        pages = by_cluster.get(cluster, [])
        if not pages:
            # Pull from tier1 if not in top30
            pages = [p for p in tier1 if p.get("cluster") == cluster][:6]
        if not pages:
            continue

        emoji = CLUSTER_EMOJI.get(cluster, "🔎")
        cluster_label = cluster.replace("-", " ").title()
        sections.append(f"### {emoji} {cluster_label}\n\n")

        for p in sorted(pages, key=lambda x: -x.get("composite_score", 0))[:8]:
            url  = f"{BASE_URL}{p['pretty_url']}"
            loc  = p.get("location_label") or ("Remote" if p.get("remote") else "All Europe")
            role = " ".join(w.capitalize() for w in p["slug"].split("-"))
            sections.append(f"- [{role} — {loc}]({url})\n")
        sections.append("\n")

    # Hub pages section
    sections.append("## 🗂️ Browse by Type\n\n")
    hubs = [
        ("/en/jobs/remote-jobs",   "Remote Jobs in Europe"),
        ("/en/jobs/tech-jobs",     "Tech Jobs"),
        ("/en/jobs/ai-jobs",       "AI & Machine Learning Jobs"),
        ("/en/jobs/startup-jobs",  "Startup Jobs"),
        ("/fr/jobs/teletravail",   "Emplois en télétravail"),
        ("/de/jobs/remote-stellen","Remote Stellen"),
    ]
    for path, label in hubs:
        sections.append(f"- [{label}]({BASE_URL}{path})\n")
    sections.append("\n")

    # Location index
    sections.append("## 🌍 Browse by Location\n\n")
    locations = [
        ("switzerland", "Switzerland 🇨🇭"), ("zurich", "Zurich"),
        ("geneva", "Geneva"), ("lausanne", "Lausanne"),
        ("france", "France 🇫🇷"), ("paris", "Paris"),
        ("germany", "Germany 🇩🇪"), ("berlin", "Berlin"), ("munich", "Munich"),
        ("united-kingdom", "United Kingdom 🇬🇧"), ("london", "London"),
        ("netherlands", "Netherlands 🇳🇱"), ("amsterdam", "Amsterdam"),
        ("remote", "Remote 🌍"),
    ]
    for loc_slug, loc_label in locations:
        # Find a representative page for this location
        loc_pages = [p for p in tier1 if p.get("location") == loc_slug]
        if loc_pages:
            best = sorted(loc_pages, key=lambda x: -x.get("composite_score", 0))[0]
            url = f"{BASE_URL}{best['pretty_url']}"
            sections.append(f"- [{loc_label} — browse all roles]({url})\n")
        else:
            sections.append(f"- {loc_label}\n")
    sections.append("\n")

    sections.append(FOOTER.format(timestamp=ts))
    return "".join(sections)


def main():
    t1_path = DATA_DIR / "tier1_pages.json"
    t30_path = DATA_DIR / "top30_launch.json"

    if not t1_path.exists() or not t30_path.exists():
        log.error("Run 07 first!"); return

    with open(t1_path, encoding="utf-8") as f:
        tier1 = json.load(f)
    with open(t30_path, encoding="utf-8") as f:
        top30 = json.load(f)

    readme = generate_readme(top30, tier1)

    out = ROOT_DIR / "README.md"
    with open(out, "w", encoding="utf-8") as f:
        f.write(readme)
    log.info(f"✓ README.md written ({len(readme.splitlines())} lines)")

    # Also write a compact job index JSON (for the frontend to consume)
    index = [
        {
            "url": f"{BASE_URL}{p['pretty_url']}",
            "title": p.get("content", {}).get("h1", p["slug"]),
            "cluster": p["cluster"],
            "location": p.get("location"),
            "remote": p.get("remote", False),
            "score": p.get("composite_score", 0),
            "locale": p["locale"],
        }
        for p in sorted(tier1, key=lambda x: -x.get("composite_score", 0))[:200]
    ]
    with open(DATA_DIR / "page_index.json", "w", encoding="utf-8") as f:
        json.dump(index, f, indent=2, ensure_ascii=False)
    log.info(f"✓ page_index.json ({len(index)} pages)")


if __name__ == "__main__":
    main()
