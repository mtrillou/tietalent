#!/usr/bin/env python3
"""
08_rich_content.py V3 — NO salary data. Qualitative, role-specific content.
Each Tier-1 EN page: title/meta, intro, companies, skills, role-types, 5 FAQs,
FAQPage schema, BreadcrumbList schema. Robots=noindex for T2/T3.
"""
import json, logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)
DATA_DIR  = Path(__file__).parent.parent / "data"
PAGES_DIR = Path(__file__).parent.parent / "pages"

ROLE_DATA = {
  "ai-engineer":{"demand_signal":"very high","yoy_growth":"+68%","remote_pct":"72%",
    "top_companies":["Mistral AI","Hugging Face","Aleph Alpha","Google DeepMind","Cohere","Poolside","LightOn","EPFL spin-offs"],
    "top_skills":["LLMs","PyTorch","RAG","LangChain","Vector DBs","MLOps","Python","Distributed Training"],
    "role_types":["Research Engineer","Applied AI Engineer","LLM Engineer","AI Platform Engineer","MLOps Engineer","AI Product Engineer"],
    "market_insight":"AI engineering is the fastest-growing engineering category in Europe. Demand is doubling year-on-year as companies move from AI experimentation to production deployment.",
    "why_tietalent":"Top AI teams at European companies actively scout TieTalent profiles rather than posting to general job boards — the platform attracts candidates with verifiable AI project experience."},
  "software-engineer":{"demand_signal":"high","yoy_growth":"+18%","remote_pct":"62%",
    "top_companies":["Swisstopo","Nestlé Digital","Doctolib","N26","Zalando","Alan","Revolut","Swisscom"],
    "top_skills":["Python","TypeScript","React","Kubernetes","PostgreSQL","REST APIs","CI/CD","System Design"],
    "role_types":["Backend Engineer","Frontend Engineer","Full-Stack Engineer","Staff Engineer","Principal Engineer","Platform Engineer"],
    "market_insight":"Software engineering roles in Europe remain in sustained demand, with companies consistently hiring across seniority levels. Specialization in cloud-native architectures commands a clear market premium.",
    "why_tietalent":"TieTalent's reverse-hiring model is particularly effective for software engineers — companies approach you based on your stack and experience level."},
  "data-scientist":{"demand_signal":"very high","yoy_growth":"+31%","remote_pct":"58%",
    "top_companies":["CERN","Roche","BNP Paribas","Airbus","SAP","Deezer","Leboncoin","Criteo"],
    "top_skills":["Python","PyTorch","Scikit-learn","SQL","Spark","Statistics","A/B Testing","MLflow"],
    "role_types":["Applied Data Scientist","Research Scientist","ML Engineer","Data Science Lead","Quantitative Analyst","NLP Scientist"],
    "market_insight":"Data science in Europe is maturing — demand has shifted from generalist roles toward NLP, computer vision, and causal inference specialisations. Senior profiles remain significantly undersupplied.",
    "why_tietalent":"Data science candidates on TieTalent receive an average of 3–5 company approaches within the first two weeks of profile activation."},
  "machine-learning-engineer":{"demand_signal":"very high","yoy_growth":"+42%","remote_pct":"65%",
    "top_companies":["DeepMind","Spotify","Booking.com","Revolut","iFood","Klarna","Onfido","Meero"],
    "top_skills":["PyTorch","TensorFlow","MLOps","Kubeflow","Feature Engineering","Model Serving","Python","Distributed Training"],
    "role_types":["ML Engineer","MLOps Engineer","Research Engineer","Applied ML Engineer","ML Platform Engineer","Inference Engineer"],
    "market_insight":"ML engineering has become a distinct discipline from data science. European companies are investing heavily in ML infrastructure, creating sustained demand for engineers who bridge research and production.",
    "why_tietalent":"ML engineers often find traditional job boards flooded with irrelevant matches. TieTalent's skill-based matching surfaces roles aligned specifically with your framework expertise."},
  "full-stack-developer":{"demand_signal":"high","yoy_growth":"+22%","remote_pct":"68%",
    "top_companies":["BlaBlaCar","Contentsquare","ManoMano","Sorare","Doctolib","PayFit","Swissquote","Alan"],
    "top_skills":["React","Node.js","TypeScript","PostgreSQL","Docker","GraphQL","AWS/GCP","Testing"],
    "role_types":["Full-Stack Engineer","Senior Full-Stack Developer","Tech Lead","Staff Engineer","Solo Developer","Founding Engineer"],
    "market_insight":"Full-stack developers remain highly sought in European startups and scale-ups, where breadth of capability is valued over deep specialisation. Remote-first positions dominate this market.",
    "why_tietalent":"Startups use TieTalent to find full-stack talent who can contribute across the stack from day one. Profile-based matching means your project history speaks louder than your CV."},
  "product-manager":{"demand_signal":"high","yoy_growth":"+22%","remote_pct":"55%",
    "top_companies":["Spotify","Booking.com","Swissquote","Contentsquare","ManoMano","Sorare","Heetch","Mirakl"],
    "top_skills":["Roadmapping","OKRs","User Research","SQL","Figma","Agile","Stakeholder Management","Analytics"],
    "role_types":["Product Manager","Senior PM","Principal PM","Group PM","Head of Product","CPO"],
    "market_insight":"Product management in Europe has professionalised — companies differentiate between growth PMs, platform PMs, and B2B specialists. Candidates with both technical fluency and business acumen are especially in demand.",
    "why_tietalent":"Senior PMs frequently use TieTalent to explore opportunities without signalling an active job search to their current employer — the confidential profile feature is particularly valued."},
  "devops-engineer":{"demand_signal":"high","yoy_growth":"+28%","remote_pct":"70%",
    "top_companies":["Grafana Labs","HashiCorp","CERN","PostFinance","Six Group","SBB","Ricardo","Swisscom"],
    "top_skills":["Kubernetes","Terraform","CI/CD","AWS/GCP/Azure","Prometheus","Helm","Linux","Python/Bash"],
    "role_types":["DevOps Engineer","Platform Engineer","Infrastructure Engineer","SRE","Cloud Engineer","DevSecOps Engineer"],
    "market_insight":"DevOps and platform engineering roles are increasingly remote-first. The shift toward internal developer platforms (IDPs) is creating demand for engineers who can abstract infrastructure complexity.",
    "why_tietalent":"DevOps engineers with cloud certifications and Kubernetes experience are among the most approached profiles on TieTalent — infrastructure talent is in persistent short supply."},
  "site-reliability-engineer":{"demand_signal":"high","yoy_growth":"+35%","remote_pct":"72%",
    "top_companies":["Google","Meta","Spotify","Cloudflare","Criteo","Deezer","OVHcloud","Scaleway"],
    "top_skills":["SLOs/SLAs","Kubernetes","Incident Response","Observability","Go/Python","Chaos Engineering","Distributed Systems","Linux"],
    "role_types":["SRE","Platform SRE","Production Engineer","Infrastructure SRE","Staff SRE","Embedded SRE"],
    "market_insight":"SRE is growing rapidly in Europe as companies mature their reliability practices. The role sits at the intersection of software engineering and operations.",
    "why_tietalent":"SREs with demonstrable on-call experience and incident postmortems attract immediate company interest — reliability track records are hard to fake and highly valued."},
  "backend-engineer":{"demand_signal":"high","yoy_growth":"+20%","remote_pct":"64%",
    "top_companies":["SoundCloud","Contentful","Personio","Celonis","TeamViewer","Xing","Zalando","Delivery Hero"],
    "top_skills":["Python/Go/Java","Microservices","PostgreSQL","Redis","gRPC","Docker","Kafka","System Design"],
    "role_types":["Backend Engineer","API Engineer","Systems Engineer","Infrastructure Backend","Staff Backend","Tech Lead"],
    "market_insight":"Backend engineering demand is durable and spans all sectors. Specialisation in high-throughput systems, event-driven architectures, or domain-driven design commands premium positioning.",
    "why_tietalent":"Backend engineers with strong system design fundamentals receive the highest volume of company approaches on TieTalent, particularly from fintech and marketplace companies."},
  "nlp-engineer":{"demand_signal":"very high","yoy_growth":"+85%","remote_pct":"75%",
    "top_companies":["Mistral AI","DeepL","Synthesio","expert.ai","Curai Health","Aleph Alpha","Cohere","LightOn"],
    "top_skills":["Transformers","spaCy","LLM Fine-tuning","PyTorch","HuggingFace","RAG","Named Entity Recognition","Python"],
    "role_types":["NLP Engineer","Computational Linguist","Research Engineer","Applied NLP Scientist","Conversational AI Engineer","LLM Engineer"],
    "market_insight":"NLP engineering is the most supply-constrained AI specialisation in Europe. The LLM revolution has dramatically expanded what companies are building while the talent pool remains small.",
    "why_tietalent":"NLP specialists on TieTalent are approached by companies within hours of profile activation. The supply/demand imbalance makes this one of the most powerful markets to participate in passively."},
  "computer-vision-engineer":{"demand_signal":"high","yoy_growth":"+47%","remote_pct":"60%",
    "top_companies":["Prophesee","Valeo","NavVis","Meero","Roboflow","Ledger","Helsing","Onfido"],
    "top_skills":["PyTorch","OpenCV","YOLO/DETR","3D Vision","Camera Calibration","Edge Deployment","Python","CUDA"],
    "role_types":["Computer Vision Engineer","Perception Engineer","3D Vision Specialist","Edge Vision Engineer","Research Engineer","Senior CV Engineer"],
    "market_insight":"CV engineering demand is driven by autonomous systems, manufacturing quality control, and spatial computing. European deeptech companies — especially in France and Germany — are building world-class CV teams.",
    "why_tietalent":"Computer vision engineers with robotics or edge deployment experience are among the hardest profiles to recruit in Europe, giving TieTalent-listed candidates significant negotiating leverage."},
  "data-engineer":{"demand_signal":"high","yoy_growth":"+38%","remote_pct":"65%",
    "top_companies":["Tamedia","Scout24","Sunrise","TX Group","Swisscom Digital","Zalando","Booking.com","GetYourGuide"],
    "top_skills":["dbt","Airflow","Spark","SQL","Python","Snowflake/BigQuery","Kafka","Data Vault"],
    "role_types":["Data Engineer","Analytics Engineer","Data Platform Engineer","Senior Data Engineer","Data Architect","Staff Data Engineer"],
    "market_insight":"Data engineering is the backbone of the modern analytics stack. European companies are migrating from legacy warehouses to cloud-native architectures — demand for engineers who understand both worlds is sustained.",
    "why_tietalent":"Data engineers who demonstrate dbt + cloud warehouse experience consistently attract the highest quantity of quality matches on TieTalent."},
  "platform-engineer":{"demand_signal":"high","yoy_growth":"+40%","remote_pct":"71%",
    "top_companies":["Grafana Labs","HashiCorp","Snyk","Datadog","Cloudflare","OVHcloud","Scaleway","Klarna"],
    "top_skills":["Kubernetes","Internal Developer Platforms","Terraform","Backstage","CI/CD","Go","Python","Service Mesh"],
    "role_types":["Platform Engineer","Developer Platform Engineer","Infrastructure Platform Lead","Staff Platform Engineer","Cloud Platform Engineer"],
    "market_insight":"Platform engineering is emerging as the dedicated function for developer experience and infrastructure abstraction. Companies that reach ~50 engineers typically hire their first dedicated platform team.",
    "why_tietalent":"Platform engineers with IDP experience — particularly Backstage, Port, or custom internal tools — are at the leading edge of a fast-growing discipline and attract strong company interest."},
  "kubernetes-engineer":{"demand_signal":"high","yoy_growth":"+33%","remote_pct":"73%",
    "top_companies":["SUSE","Giant Swarm","Heptio alumni","CERN","OVHcloud","Exoscale","Elastisys","Weaveworks"],
    "top_skills":["Kubernetes","Helm","Operator SDK","Istio/Linkerd","Prometheus/Grafana","etcd","Go","ArgoCD"],
    "role_types":["Kubernetes Engineer","Cloud Native Engineer","Container Platform Engineer","K8s Operator Developer","CNCF Engineer"],
    "market_insight":"Deep Kubernetes expertise commands a market premium — particularly around multi-cluster management, GitOps workflows, and operator development. The CNCF ecosystem continues to expand the role scope.",
    "why_tietalent":"Kubernetes specialists are rare enough that companies frequently approach them directly rather than posting open roles — TieTalent's passive-candidate model suits this market perfectly."},
  "cybersecurity-engineer":{"demand_signal":"high","yoy_growth":"+29%","remote_pct":"58%",
    "top_companies":["Kudelski Group","WISeKey","RUAG","Acronis","Snyk","Checkmarx","SentinelOne","Wiz"],
    "top_skills":["Penetration Testing","SIEM","Incident Response","ISO 27001","Cloud Security","AppSec","Threat Modelling","OWASP"],
    "role_types":["Security Engineer","AppSec Engineer","Cloud Security Engineer","SOC Analyst","Red Team Engineer","Security Architect"],
    "market_insight":"Cybersecurity hiring in Europe is driven by regulatory pressure (NIS2, DORA). Companies are building security into product teams rather than relying solely on centralised security functions.",
    "why_tietalent":"Cybersecurity professionals with both offensive and defensive experience are consistently among the most urgently sought profiles on TieTalent."},
}

DEFAULT_ROLE = {"demand_signal":"moderate","yoy_growth":"+15%","remote_pct":"50%",
  "top_companies":["Google","Microsoft","Zalando","BlaBlaCar","Doctolib","Klarna","N26","Revolut"],
  "top_skills":["Analytical Thinking","Project Management","Communication","Data Analysis","Collaboration"],
  "role_types":["Junior","Mid-level","Senior","Lead","Head of","Director"],
  "market_insight":"Demand for this role in Europe remains consistent, with opportunities across fintech, healthtech, and SaaS companies of all sizes.",
  "why_tietalent":"TieTalent's reverse-hiring model means you create one profile and relevant companies apply to you — saving weeks of outbound job searching."}

def render(page):
    slug=page["slug"]; job_title=page.get("job_title",slug.replace("-"," "))
    tc=" ".join(w.capitalize() for w in job_title.split())
    loc=page.get("location"); ll=page.get("location_label") or (loc or "").replace("-"," ").title()
    remote=page.get("remote",False); pt=page["type"]
    role=ROLE_DATA.get(slug,DEFAULT_ROLE)
    cos=", ".join(role["top_companies"][:4]); sk2=role["top_skills"][:2]
    d=role["demand_signal"]; g=role["yoy_growth"]; rp=role["remote_pct"]

    # Title/meta
    if pt=="core":
        title=f"{tc} Jobs in Europe — Verified Openings | TieTalent"
        meta=f"Find {job_title} jobs at top European companies. Browse verified openings and let companies apply to you on TieTalent."
        h1=f"{tc} Jobs"
    elif pt=="location":
        title=f"{tc} Jobs in {ll} — Apply Without a CV | TieTalent"
        meta=f"Explore {job_title} jobs in {ll}. Verified openings, no cover letter needed. Create a free TieTalent profile."
        h1=f"{tc} Jobs in {ll}"
    elif pt=="remote":
        title=f"Remote {tc} Jobs in Europe — Work From Anywhere | TieTalent"
        meta=f"Find remote {job_title} jobs at European companies offering full flexibility. Browse roles and let the right companies apply to you."
        h1=f"Remote {tc} Jobs"
    else:
        title=f"Remote {tc} Jobs in {ll} | TieTalent"
        meta=f"Remote {job_title} positions in {ll}. Hybrid and full-remote options. Apply via TieTalent."
        h1=f"Remote {tc} Jobs in {ll}"

    # Intro
    if pt=="core":
        intro=(f"Demand for {job_title} professionals across Europe is at a {d} level, "
               f"with year-on-year growth of {g} driven by companies expanding their technical and product teams. "
               f"Employers including {cos} are actively building out their {job_title} functions.\n\n"
               f"{role['market_insight']}\n\n"
               f"{role['why_tietalent']} Compensation varies widely depending on seniority, company stage, "
               f"and location — specialists with deep expertise in {sk2[0]} and {sk2[1]} command a significant market premium.")
    elif pt=="location":
        intro=(f"{ll} is one of Europe's most active markets for {job_title} professionals, "
               f"with {d} hiring activity and {g} year-on-year growth. "
               f"Companies including {cos} have active openings there.\n\n"
               f"{role['market_insight']}\n\n"
               f"Compensation varies by seniority, company stage, and specialisation — depth in "
               f"{sk2[0]} and {sk2[1]} typically commands a premium. {role['why_tietalent']}")
    elif pt=="remote":
        intro=(f"Remote {job_title} positions now make up {rp} of active European openings. "
               f"Leading companies including {cos} have adopted distributed team structures.\n\n"
               f"{role['market_insight']}\n\n"
               f"Remote compensation varies based on the hiring company's location and philosophy. {role['why_tietalent']}")
    else:
        intro=(f"Remote {job_title} positions in {ll} combine local market dynamics with distributed work flexibility. "
               f"{rp} of {job_title} openings in {ll} now include a remote or hybrid option.\n\n"
               f"{role['market_insight']}\n\n"
               f"Compensation varies by employer, seniority, and the specific remote arrangement. {role['why_tietalent']}")

    loc_str=f" in {ll}" if ll and pt not in("core","remote") else ""
    faqs=[
        {"question":f"How do I find {job_title} jobs{loc_str}?",
         "answer":f"The most effective approach is to make your profile visible to active employers. On TieTalent, companies with open {job_title} positions approach you directly — reducing the time and effort of a job search significantly."},
        {"question":f"What skills are most important for a {job_title}?",
         "answer":f"The most consistently required skills are {', '.join(role['top_skills'][:4])}. Employers also value clear written communication, autonomous working, and a track record of shipping to production."},
        {"question":f"Which companies are hiring {job_title}s{loc_str}?",
         "answer":f"Active hirers include {', '.join(role['top_companies'][:3])} and many others. On TieTalent, verified openings are updated daily. Demand is currently {d} with {g} year-on-year growth."},
        {"question":f"Are there remote {job_title} jobs?",
         "answer":f"{rp} of {job_title} positions list remote or hybrid options. TieTalent's remote filter shows roles where distributed work is explicitly confirmed, not just implied."},
        {"question":f"What types of {job_title} roles are available?",
         "answer":f"The market includes: {', '.join(role['role_types'][:4])}. TieTalent normalises titles so your profile surfaces for all equivalent positions."},
    ]
    faq_schema={"@context":"https://schema.org","@type":"FAQPage","mainEntity":[
        {"@type":"Question","name":f["question"],"acceptedAnswer":{"@type":"Answer","text":f["answer"]}}
        for f in faqs]}
    robots="index,follow" if page.get("tier",2)==1 else "noindex,follow"
    return {
        "pretty_url":page["pretty_url"],"internal_url":page["internal_url"],
        "locale":page["locale"],"type":pt,"slug":slug,"location":loc,"remote":remote,
        "cluster":page.get("cluster","other"),"tier":page.get("tier",2),
        "composite_score":page.get("composite_score",0),"robots":robots,
        "alternate_urls":page.get("alternate_urls",{}),
        "content":{"title_tag":title,"meta_description":meta,"h1":h1,"intro":intro,
            "companies_section":{"title":f"Top Companies Hiring {tc}s{loc_str}",
                "companies":role["top_companies"],
                "note":f"Active {job_title} openings on TieTalent, verified and updated daily."},
            "skills_section":{"title":f"Most In-Demand Skills for {tc} Roles",
                "technical":role["top_skills"][:6],
                "soft":["Systems Thinking","Async Communication","Technical Documentation","Ownership Mentality"],
                "note":"Focus on demonstrating depth in 2–3 core areas rather than breadth across all of them."},
            "role_types_section":{"title":f"Types of {tc} Roles Available","types":role["role_types"],
                "note":"TieTalent normalises job titles so your profile surfaces for all equivalent positions."},
            "faq":faqs,"faq_schema":faq_schema},
    }

def main():
    t1=json.load(open(DATA_DIR/"tier1_pages.json",encoding="utf-8"))
    en=[p for p in t1 if p["locale"]=="en"]
    log.info(f"Rendering {len(en)} Tier-1 EN pages…")
    rendered=sorted([render(p) for p in en],key=lambda x:-x["composite_score"])
    out=DATA_DIR/"tier1_rich_en.json"
    json.dump(rendered,open(out,"w",encoding="utf-8"),indent=2,ensure_ascii=False)
    log.info(f"✓ {len(rendered)} pages → {out}")
    (PAGES_DIR/"samples").mkdir(parents=True,exist_ok=True)
    if rendered:
        json.dump(rendered[0],open(PAGES_DIR/"samples"/"tier1_sample_rich.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
        log.info("✓ sample page written")

if __name__=="__main__": main()
