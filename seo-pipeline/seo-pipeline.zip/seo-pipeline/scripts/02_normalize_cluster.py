#!/usr/bin/env python3
"""
Step 2: Normalize & cluster job titles into canonical categories.
Input:  data/sitemap_records.json
Output: data/normalized_jobs.json
        data/clusters.json
"""

import json
import re
import logging
from pathlib import Path
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)

DATA_DIR = Path(__file__).parent.parent / "data"

# ---------------------------------------------------------------------------
# Cluster rules — order matters; first match wins
# ---------------------------------------------------------------------------
CLUSTER_RULES = [
    # Engineering
    {"cluster": "software-engineering",   "keywords": ["software engineer", "software developer", "full stack", "fullstack", "full-stack"]},
    {"cluster": "backend-engineering",    "keywords": ["backend", "back-end", "back end", "node.js", "django", "rails", "spring boot"]},
    {"cluster": "frontend-engineering",   "keywords": ["frontend", "front-end", "front end", "react", "vue", "angular", "ui developer"]},
    {"cluster": "mobile-development",     "keywords": ["ios", "android", "react native", "flutter", "mobile developer", "swift", "kotlin"]},
    {"cluster": "devops-sre",             "keywords": ["devops", "sre", "site reliability", "platform engineer", "infrastructure", "cloud engineer", "kubernetes", "terraform"]},
    {"cluster": "data-engineering",       "keywords": ["data engineer", "etl", "pipeline", "dbt", "spark", "hadoop", "airflow"]},
    {"cluster": "data-science",           "keywords": ["data scientist", "machine learning", "ml engineer", "deep learning", "nlp", "computer vision"]},
    {"cluster": "data-analytics",         "keywords": ["data analyst", "data analytics", "business intelligence", "bi analyst", "tableau", "power bi", "looker"]},
    {"cluster": "ai-ml",                  "keywords": ["ai engineer", "artificial intelligence", "llm", "generative ai", "prompt engineer"]},
    {"cluster": "cybersecurity",          "keywords": ["security engineer", "cybersecurity", "penetration", "soc analyst", "infosec", "appsec"]},
    {"cluster": "product-management",     "keywords": ["product manager", "product owner", "product lead", "head of product"]},
    {"cluster": "ux-design",              "keywords": ["ux designer", "ui/ux", "user experience", "interaction designer", "product designer"]},
    {"cluster": "sales",                  "keywords": ["sales manager", "account executive", "sales director", "business development", "account manager", "sales engineer"]},
    {"cluster": "marketing",              "keywords": ["marketing manager", "growth", "seo specialist", "content marketer", "digital marketing", "performance marketing", "cmo"]},
    {"cluster": "finance",                "keywords": ["financial analyst", "cfo", "controller", "treasury", "accounting", "audit", "finance manager"]},
    {"cluster": "hr-people",              "keywords": ["hr manager", "recruiter", "talent acquisition", "people operations", "hrbp", "human resources"]},
    {"cluster": "operations",             "keywords": ["operations manager", "chief of staff", "coo", "operations analyst", "business operations"]},
    {"cluster": "consulting",             "keywords": ["consultant", "strategy", "management consulting", "advisory"]},
    {"cluster": "legal",                  "keywords": ["lawyer", "legal counsel", "general counsel", "compliance", "paralegal"]},
    {"cluster": "customer-success",       "keywords": ["customer success", "customer experience", "customer support", "technical support", "help desk"]},
    {"cluster": "project-management",     "keywords": ["project manager", "program manager", "scrum master", "agile coach", "pmo"]},
]

# High-value locations for combination pages
PRIORITY_LOCATIONS = [
    # Countries (tier 1 — highest SEO value for TieTalent audience)
    {"slug": "switzerland",     "label": "Switzerland",     "tier": 1},
    {"slug": "france",          "label": "France",          "tier": 1},
    {"slug": "germany",         "label": "Germany",         "tier": 1},
    {"slug": "united-kingdom",  "label": "United Kingdom",  "tier": 1},
    {"slug": "netherlands",     "label": "Netherlands",     "tier": 1},
    {"slug": "remote",          "label": "Remote",          "tier": 1},
    # Cities (tier 2)
    {"slug": "zurich",          "label": "Zurich",          "tier": 2},
    {"slug": "geneva",          "label": "Geneva",          "tier": 2},
    {"slug": "paris",           "label": "Paris",           "tier": 2},
    {"slug": "berlin",          "label": "Berlin",          "tier": 2},
    {"slug": "london",          "label": "London",          "tier": 2},
    {"slug": "amsterdam",       "label": "Amsterdam",       "tier": 2},
    {"slug": "barcelona",       "label": "Barcelona",       "tier": 2},
    {"slug": "munich",          "label": "Munich",          "tier": 2},
    {"slug": "lausanne",        "label": "Lausanne",        "tier": 2},
    {"slug": "bern",            "label": "Bern",            "tier": 2},
    {"slug": "basel",           "label": "Basel",           "tier": 2},
    {"slug": "stockholm",       "label": "Stockholm",       "tier": 2},
    {"slug": "copenhagen",      "label": "Copenhagen",      "tier": 2},
    {"slug": "dublin",          "label": "Dublin",          "tier": 2},
    {"slug": "singapore",       "label": "Singapore",       "tier": 2},
]


def assign_cluster(job_title: str) -> str:
    title_lower = job_title.lower()
    for rule in CLUSTER_RULES:
        for kw in rule["keywords"]:
            if kw in title_lower:
                return rule["cluster"]
    return "other"


def normalize_title(title: str) -> str:
    """Remove extra words, standardize casing."""
    title = re.sub(r"\s+", " ", title.strip().lower())
    # Remove parenthetical qualifiers
    title = re.sub(r"\([^)]+\)", "", title).strip()
    return title


def compute_seo_score(record: dict) -> float:
    """
    Heuristic SEO potential score (0–100).
    Factors: locale_count, priority from sitemap, cluster desirability.
    """
    score = 0.0
    # Presence across multiple locales = higher demand signal
    score += record.get("locale_count", 1) * 20
    # Sitemap priority
    score += record.get("priority", 0.5) * 30
    # High-value clusters get a bonus
    high_value_clusters = {
        "software-engineering", "data-science", "ai-ml", "backend-engineering",
        "product-management", "devops-sre", "sales", "data-analytics"
    }
    if record.get("cluster") in high_value_clusters:
        score += 25
    # Cap at 100
    return min(round(score, 1), 100.0)


def main():
    src = DATA_DIR / "sitemap_records.json"
    if not src.exists():
        # Generate mock data for development when sitemaps aren't reachable
        log.warning("sitemap_records.json not found — using mock dataset")
        records = generate_mock_records()
    else:
        with open(src, encoding="utf-8") as f:
            records = json.load(f)

    # Normalize and enrich
    for r in records:
        r["job_title_normalized"] = normalize_title(r["job_title"])
        r["cluster"] = assign_cluster(r["job_title_normalized"])
        r["seo_score"] = compute_seo_score(r)

    # Build cluster map
    cluster_map: dict[str, list] = defaultdict(list)
    for r in records:
        cluster_map[r["cluster"]].append(r["slug"])

    # Top slugs by SEO score (deduplicated across locales)
    seen_slugs: set = set()
    unique_records = []
    for r in sorted(records, key=lambda x: -x["seo_score"]):
        if r["slug"] not in seen_slugs:
            seen_slugs.add(r["slug"])
            unique_records.append(r)

    top_50 = unique_records[:50]

    # Save outputs
    out_normalized = DATA_DIR / "normalized_jobs.json"
    with open(out_normalized, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, ensure_ascii=False)
    log.info(f"✓ normalized_jobs.json → {len(records)} records")

    out_clusters = DATA_DIR / "clusters.json"
    with open(out_clusters, "w", encoding="utf-8") as f:
        json.dump(
            {k: {"slugs": v, "count": len(v)} for k, v in cluster_map.items()},
            f, indent=2, ensure_ascii=False
        )
    log.info(f"✓ clusters.json → {len(cluster_map)} clusters")

    out_top50 = DATA_DIR / "top50_seo.json"
    with open(out_top50, "w", encoding="utf-8") as f:
        json.dump(top_50, f, indent=2, ensure_ascii=False)
    log.info(f"✓ top50_seo.json")

    # Also save locations
    out_locations = DATA_DIR / "priority_locations.json"
    with open(out_locations, "w", encoding="utf-8") as f:
        json.dump(PRIORITY_LOCATIONS, f, indent=2)
    log.info(f"✓ priority_locations.json")

    return records, cluster_map


def generate_mock_records():
    """Representative mock data for dev/testing when network is unavailable."""
    mock_slugs = [
        ("software-engineer", ["en", "fr", "de"]),
        ("backend-engineer", ["en", "de"]),
        ("frontend-developer", ["en", "fr"]),
        ("data-scientist", ["en", "fr", "de"]),
        ("product-manager", ["en", "fr", "de"]),
        ("devops-engineer", ["en", "de"]),
        ("machine-learning-engineer", ["en", "de"]),
        ("data-analyst", ["en", "fr", "de"]),
        ("ux-designer", ["en", "fr"]),
        ("sales-manager", ["en", "fr", "de"]),
        ("python-developer", ["en", "de"]),
        ("react-developer", ["en", "fr"]),
        ("cloud-architect", ["en", "de"]),
        ("cybersecurity-engineer", ["en"]),
        ("full-stack-developer", ["en", "fr", "de"]),
        ("ai-engineer", ["en", "de"]),
        ("data-engineer", ["en", "de"]),
        ("business-analyst", ["en", "fr"]),
        ("scrum-master", ["en", "de"]),
        ("technical-lead", ["en"]),
        ("cto", ["en", "fr"]),
        ("head-of-engineering", ["en"]),
        ("mobile-developer", ["en", "fr"]),
        ("ios-developer", ["en"]),
        ("android-developer", ["en"]),
        ("site-reliability-engineer", ["en", "de"]),
        ("platform-engineer", ["en"]),
        ("typescript-developer", ["en"]),
        ("java-developer", ["en", "de"]),
        ("golang-developer", ["en"]),
        ("rust-developer", ["en"]),
        ("kubernetes-engineer", ["en"]),
        ("nlp-engineer", ["en"]),
        ("computer-vision-engineer", ["en"]),
        ("growth-hacker", ["en", "fr"]),
        ("marketing-manager", ["en", "fr", "de"]),
        ("cfo", ["en", "fr"]),
        ("financial-analyst", ["en", "fr"]),
        ("recruiter", ["en", "fr"]),
        ("customer-success-manager", ["en", "fr"]),
        ("account-executive", ["en", "fr"]),
        ("international-sales-manager", ["fr"]),
        ("talent-acquisition-specialist", ["en", "fr"]),
        ("hr-manager", ["en", "fr", "de"]),
        ("operations-manager", ["en"]),
        ("legal-counsel", ["en", "fr"]),
        ("strategy-consultant", ["en", "fr"]),
        ("project-manager", ["en", "fr", "de"]),
        ("solutions-architect", ["en"]),
        ("staff-engineer", ["en"]),
    ]
    records = []
    for slug, locales in mock_slugs:
        for locale in locales:
            records.append({
                "url": f"https://tietalent.com/{locale}/jobs/search/{slug}/all",
                "locale": locale,
                "slug": slug,
                "job_title": slug.replace("-", " "),
                "lastmod": "2024-12-01",
                "changefreq": "weekly",
                "priority": 0.8,
                "locale_count": len(locales),
                "available_locales": sorted(locales),
            })
    return records


if __name__ == "__main__":
    main()
