#!/usr/bin/env python3
"""
07_prioritize_pages.py — V3: Balanced top30, enforced diversity.
- 4-axis scoring unchanged
- Hard cap: max 3 pages per slug in top30
- Hard cap: max 1 locale per (slug, location) combination
- Min 6 distinct clusters across top30
"""
import json, logging
from pathlib import Path
from collections import defaultdict, Counter

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)
DATA_DIR = Path(__file__).parent.parent / "data"

CLUSTER_SIGNALS = {
    "software-engineering":(2.8,3.20,9.5),"backend-engineering":(2.5,2.90,9.0),
    "frontend-engineering":(2.2,2.60,8.5),"ai-ml":(3.2,4.10,9.8),
    "data-science":(2.6,3.50,9.2),"data-analytics":(2.0,2.80,8.0),
    "data-engineering":(2.1,3.00,8.8),"devops-sre":(2.3,3.10,9.0),
    "mobile-development":(1.9,2.50,7.8),"product-management":(2.4,3.30,8.5),
    "ux-design":(1.7,2.20,7.5),"sales":(2.0,2.00,8.0),"marketing":(1.8,1.90,7.0),
    "finance":(1.6,2.40,7.5),"hr-people":(1.5,1.70,6.5),
    "project-management":(1.7,2.10,7.0),"operations":(1.4,1.80,6.0),
    "consulting":(1.5,2.00,6.5),"legal":(1.3,2.50,6.0),
    "customer-success":(1.4,1.60,6.5),"cybersecurity":(2.0,3.40,8.5),"other":(1.0,1.50,5.0),
}
LOCATION_MULT = {
    None:1.0,"remote":1.8,"switzerland":1.6,"france":1.5,"germany":1.4,
    "united-kingdom":1.3,"netherlands":1.2,"zurich":1.4,"geneva":1.3,
    "paris":1.3,"berlin":1.2,"london":1.2,"amsterdam":1.1,"barcelona":1.0,
    "munich":1.1,"lausanne":1.2,"bern":1.0,"basel":1.1,
    "stockholm":1.0,"copenhagen":1.0,"dublin":1.0,"singapore":0.9,
}
LOCALE_MULT={"en":1.0,"fr":0.65,"de":0.70}
INTENT_BASE={"core":75,"remote":88,"location":82,"location_remote":85}

def score(p):
    cl=p.get("cluster","other"); pt=p.get("type","core")
    locale=p["locale"]; loc=p.get("location")
    lcount=len(p.get("available_locales",[locale]))
    vm,cpc,demand=CLUSTER_SIGNALS.get(cl,(1.0,1.5,5.0))
    lm=LOCATION_MULT.get(loc,0.9); lam=LOCALE_MULT.get(locale,0.6)
    intent=float(INTENT_BASE.get(pt,70))
    volume=min(vm*lm*lam*30,100.0); cpc_s=min((cpc/5.0)*100,100.0)
    supply=min(demand*7+lcount*5,100.0)
    composite=round(intent*0.30+volume*0.35+cpc_s*0.20+supply*0.15,1)
    tier=1 if composite>=72 else(2 if composite>=52 else 3)
    return {**p,"intent_score":round(intent,1),"volume_score":round(volume,1),
            "cpc_score":round(cpc_s,1),"supply_score":round(supply,1),
            "composite_score":composite,"tier":tier}

def build_top30(tier1):
    """
    Build diverse top30:
    - Max 3 pages per slug
    - Max 1 page per (slug, location) — prefer EN locale
    - EN locale preferred over DE/FR for same combo
    - Min 6 distinct clusters
    """
    # Sort: prefer EN, then by score desc
    def sort_key(p): return (-p["composite_score"], 0 if p["locale"]=="en" else 1)
    sorted_t1 = sorted(tier1, key=sort_key)

    slug_count = defaultdict(int)
    slug_loc_seen = set()  # (slug, location) already taken
    cluster_count = defaultdict(int)
    result = []
    MAX_SLUG = 3
    MAX_PER_CLUSTER = 8  # soft cap to ensure spread

    for p in sorted_t1:
        if len(result) >= 30: break
        key = (p["slug"], p.get("location"))
        if slug_count[p["slug"]] >= MAX_SLUG: continue
        if key in slug_loc_seen: continue
        if cluster_count[p["cluster"]] >= MAX_PER_CLUSTER: continue
        result.append(p)
        slug_count[p["slug"]] += 1
        slug_loc_seen.add(key)
        cluster_count[p["cluster"]] += 1

    # Inject missing clusters if needed
    cluster_seen = {p["cluster"] for p in result}
    used_urls = {p["pretty_url"] for p in result}
    if len(cluster_seen) < 6:
        for p in sorted_t1:
            if p["cluster"] not in cluster_seen and p["pretty_url"] not in used_urls:
                result.append(p); cluster_seen.add(p["cluster"])
            if len(cluster_seen) >= 6: break

    return sorted(result[:30], key=lambda x: -x["composite_score"])

def main():
    with open(DATA_DIR/"page_definitions.json",encoding="utf-8") as f: pages=json.load(f)
    scored=sorted([score(p) for p in pages],key=lambda x:-x["composite_score"])
    t1=[p for p in scored if p["tier"]==1]
    t2=[p for p in scored if p["tier"]==2]
    t3=[p for p in scored if p["tier"]==3]
    log.info(f"T1:{len(t1)}  T2:{len(t2)}  T3:{len(t3)}")
    for fn,d in [("scored_pages.json",scored),("tier1_pages.json",t1),
                 ("tier2_pages.json",t2),("tier3_pages.json",t3)]:
        with open(DATA_DIR/fn,"w",encoding="utf-8") as f: json.dump(d,f,indent=2,ensure_ascii=False)
    top30=build_top30(t1)
    with open(DATA_DIR/"top30_launch.json","w",encoding="utf-8") as f:
        json.dump(top30,f,indent=2,ensure_ascii=False)
    clusters=Counter(p["cluster"] for p in top30)
    slugs=Counter(p["slug"] for p in top30)
    log.info(f"Top30: {len(top30)} pages | {len(clusters)} clusters | slug spread: max {max(slugs.values()) if slugs else 0}")
    lines=["# SEO Priority Report\n\n",
           f"Total:{len(scored)} | T1:{len(t1)} | T2:{len(t2)} | T3:{len(t3)}\n\n",
           "## Top 30 Launch Pages\n\n",
           "| # | URL | Type | Cluster | Intent | Volume | CPC | Supply | Score |\n",
           "|---|-----|------|---------|--------|--------|-----|--------|-------|\n"]
    for i,p in enumerate(top30,1):
        lines.append(f"| {i} | `{p['pretty_url']}` | {p['type']} | {p['cluster']} "
                     f"| {p['intent_score']} | {p['volume_score']} | {p['cpc_score']} "
                     f"| {p['supply_score']} | **{p['composite_score']}** |\n")
    with open(DATA_DIR/"priority_report.md","w",encoding="utf-8") as f: f.writelines(lines)
    log.info("✓ priority_report.md")

if __name__=="__main__": main()
