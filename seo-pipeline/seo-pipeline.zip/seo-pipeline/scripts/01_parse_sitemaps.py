#!/usr/bin/env python3
"""
Step 1: Parse TieTalent sitemaps → extract job titles + metadata
Sitemaps:
  - /api/v2/sitemaps/job-search-sitemap-en.xml
  - /api/v2/sitemaps/job-search-sitemap-fr.xml
  - /api/v2/sitemaps/job-search-sitemap-de.xml
"""

import re
import json
import logging
import urllib.request
from pathlib import Path
from datetime import datetime
from xml.etree import ElementTree as ET
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)

BASE_URL = "https://tietalent.com"
SITEMAPS = {
    "en": f"{BASE_URL}/api/v2/sitemaps/job-search-sitemap-en.xml",
    "fr": f"{BASE_URL}/api/v2/sitemaps/job-search-sitemap-fr.xml",
    "de": f"{BASE_URL}/api/v2/sitemaps/job-search-sitemap-de.xml",
}
OUTPUT_DIR = Path(__file__).parent.parent / "data"
OUTPUT_DIR.mkdir(exist_ok=True)

# Regex: /{locale}/jobs/search/{slug}/all
URL_PATTERN = re.compile(r"/(?P<locale>[a-z]{2})/jobs/search/(?P<slug>[^/]+)/all")


def fetch_sitemap(locale: str, url: str) -> list[dict]:
    """Download & parse a sitemap XML → list of raw URL records."""
    log.info(f"Fetching [{locale}] {url}")
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            raw = resp.read()
    except Exception as e:
        log.warning(f"  ✗ Could not fetch {url}: {e}")
        return []

    try:
        root = ET.fromstring(raw)
    except ET.ParseError as e:
        log.error(f"  ✗ XML parse error: {e}")
        return []

    ns = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    records = []
    for url_el in root.findall("sm:url", ns):
        loc = url_el.findtext("sm:loc", namespaces=ns) or ""
        lastmod = url_el.findtext("sm:lastmod", namespaces=ns) or ""
        changefreq = url_el.findtext("sm:changefreq", namespaces=ns) or ""
        priority = url_el.findtext("sm:priority", namespaces=ns) or ""

        m = URL_PATTERN.search(loc)
        if not m:
            continue

        slug = m.group("slug")
        title = slug.replace("-", " ")

        records.append({
            "url": loc,
            "locale": locale,
            "slug": slug,
            "job_title": title,
            "lastmod": lastmod,
            "changefreq": changefreq,
            "priority": float(priority) if priority else 0.5,
        })

    log.info(f"  ✓ Parsed {len(records)} URLs")
    return records


def deduplicate_slugs(all_records: list[dict]) -> list[dict]:
    """
    Per slug, keep locale-specific entries but flag cross-locale presence.
    Also compute a global 'locale_count' for prioritization.
    """
    slug_locales: dict[str, set] = defaultdict(set)
    for r in all_records:
        slug_locales[r["slug"]].add(r["locale"])

    enriched = []
    seen = set()
    for r in all_records:
        key = (r["slug"], r["locale"])
        if key in seen:
            continue
        seen.add(key)
        r["locale_count"] = len(slug_locales[r["slug"]])
        r["available_locales"] = sorted(slug_locales[r["slug"]])
        enriched.append(r)

    return enriched


def main():
    all_records: list[dict] = []
    for locale, url in SITEMAPS.items():
        all_records.extend(fetch_sitemap(locale, url))

    all_records = deduplicate_slugs(all_records)
    log.info(f"Total records after dedup: {len(all_records)}")

    # Save full dataset
    out_path = OUTPUT_DIR / "sitemap_records.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(all_records, f, indent=2, ensure_ascii=False)
    log.info(f"✓ Saved → {out_path}")

    # Summary stats
    by_locale = defaultdict(int)
    for r in all_records:
        by_locale[r["locale"]] += 1

    log.info("=== Summary ===")
    for loc, count in sorted(by_locale.items()):
        log.info(f"  {loc}: {count} job slugs")
    log.info(f"  Total unique slugs: {len({r['slug'] for r in all_records})}")

    return all_records


if __name__ == "__main__":
    main()
