#!/usr/bin/env python3
"""
Step 8: Generate new sitemaps for programmatic SEO pages.
Does NOT duplicate /jobs/search/... URLs — only new pretty URLs.
Output: sitemaps/seo-pages-{locale}.xml
        sitemaps/seo-hubs.xml
"""

import json
import logging
from pathlib import Path
from datetime import date
from xml.etree import ElementTree as ET
from xml.dom import minidom

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)

DATA_DIR    = Path(__file__).parent.parent / "data"
SITEMAP_DIR = Path(__file__).parent.parent / "sitemaps"
SITEMAP_DIR.mkdir(exist_ok=True)

BASE_URL  = "https://tietalent.com"
TODAY     = date.today().isoformat()

# Priority by page type
PRIORITY_MAP = {
    "core":             "0.9",
    "remote":           "0.8",
    "location":         "0.75",
    "location_remote":  "0.7",
    "hub":              "1.0",
}

CHANGEFREQ_MAP = {
    "core":             "daily",
    "remote":           "daily",
    "location":         "weekly",
    "location_remote":  "weekly",
    "hub":              "daily",
}

SM_NS = "http://www.sitemaps.org/schemas/sitemap/0.9"
XHTML_NS = "http://www.w3.org/1999/xhtml"


def make_sitemap(urls: list[dict]) -> str:
    """
    urls: list of {loc, lastmod, changefreq, priority, alternates: {locale: url}}
    Returns pretty-printed XML string.
    """
    # Build raw XML manually to avoid duplicate namespace issues with ElementTree
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<urlset xmlns="{SM_NS}" xmlns:xhtml="{XHTML_NS}">',
    ]
    for entry in urls:
        lines.append("  <url>")
        lines.append(f"    <loc>{entry['loc']}</loc>")
        lines.append(f"    <lastmod>{entry.get('lastmod', TODAY)}</lastmod>")
        lines.append(f"    <changefreq>{entry.get('changefreq', 'weekly')}</changefreq>")
        lines.append(f"    <priority>{entry.get('priority', '0.7')}</priority>")
        alts = entry.get("alternates", {})
        if alts:
            locale = entry.get("locale", "en")
            lines.append(f'    <xhtml:link rel="alternate" hreflang="{locale}" href="{entry["loc"]}"/>')
            for alt_locale, alt_url in alts.items():
                lines.append(f'    <xhtml:link rel="alternate" hreflang="{alt_locale}" href="{BASE_URL}{alt_url}"/>')
        lines.append("  </url>")
    lines.append("</urlset>")
    return "\n".join(lines)



def main():
    src = DATA_DIR / "rendered_pages.json"
    if not src.exists():
        log.error("Run 04 first!")
        return

    with open(src, encoding="utf-8") as f:
        pages = json.load(f)

    # Group by locale
    by_locale: dict[str, list] = {"en": [], "fr": [], "de": []}
    for p in pages:
        entry = {
            "loc":        f"{BASE_URL}{p['pretty_url']}",
            "lastmod":    TODAY,
            "changefreq": CHANGEFREQ_MAP.get(p["type"], "weekly"),
            "priority":   PRIORITY_MAP.get(p["type"], "0.7"),
            "locale":     p["locale"],
            "alternates": p.get("alternate_urls", {}),
        }
        locale = p["locale"]
        if locale in by_locale:
            by_locale[locale].append(entry)

    sitemap_files = []
    for locale, entries in by_locale.items():
        if not entries:
            continue
        xml = make_sitemap(entries)
        out_path = SITEMAP_DIR / f"seo-pages-{locale}.xml"
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(xml)
        log.info(f"✓ {out_path.name}  ({len(entries)} URLs)")
        sitemap_files.append(str(out_path))

    # Generate sitemap index
    index_entries = []
    for locale in ["en", "fr", "de"]:
        index_entries.append({
            "loc": f"{BASE_URL}/sitemaps/seo-pages-{locale}.xml",
            "lastmod": TODAY,
        })

    ET.register_namespace("", SM_NS)
    idx_root = ET.Element(f"{{{SM_NS}}}sitemapindex")
    for e in index_entries:
        sm_el = ET.SubElement(idx_root, f"{{{SM_NS}}}sitemap")
        ET.SubElement(sm_el, f"{{{SM_NS}}}loc").text = e["loc"]
        ET.SubElement(sm_el, f"{{{SM_NS}}}lastmod").text = e["lastmod"]

    idx_xml = ET.tostring(idx_root, encoding="unicode")
    idx_dom = minidom.parseString(f'<?xml version="1.0" encoding="UTF-8"?>{idx_xml}')
    idx_out = SITEMAP_DIR / "sitemap-index.xml"
    with open(idx_out, "w", encoding="utf-8") as f:
        f.write(idx_dom.toprettyxml(indent="  ", encoding=None))
    log.info(f"✓ sitemap-index.xml written")

    total = sum(len(v) for v in by_locale.values())
    log.info(f"Total sitemap entries: {total}")


if __name__ == "__main__":
    main()
