#!/usr/bin/env python3
"""
11_multi_repo.py — Jobright-style multi-repository SEO strategy.
Creates 4 GitHub repos, each owning a niche keyword cluster.
Each repo:
  - Owns specific job clusters → gets crawled for its theme
  - Has an engaging README with curated job tables + market insights
  - Freshness hook at the top (updated timestamp + counts)
  - Links back to TieTalent canonical pages
  - Updates independently (different cron cadences possible)

Repo strategy:
  ai-jobs-europe             → ai-ml, nlp, computer-vision
  remote-tech-jobs-europe    → all clusters, remote filter only
  software-engineer-jobs-europe → software-eng, backend, frontend, devops
  data-jobs-europe           → data-science, data-eng, data-analytics

Why this works:
  - GitHub DA ~250 → strong link equity to TieTalent pages
  - Each repo targets a distinct keyword cluster Google can categorize
  - Hourly commits = freshness signal (same as Jobright's strategy)
  - Stars/forks → organic social backlinks from dev communities
"""

import json, logging, random
from pathlib import Path
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)

DATA_DIR  = Path(__file__).parent.parent / "data"
REPOS_DIR = Path(__file__).parent.parent / "repos"
BASE_URL  = "https://tietalent.com"

REPOS = {
    "ai-jobs-europe": {
        "title":       "AI Jobs in Europe 🤖",
        "tagline":     "Curated AI, Machine Learning, and NLP jobs from top European companies — updated daily.",
        "clusters":    ["ai-ml", "data-science"],
        "slug_filter": ["ai-engineer","machine-learning-engineer","nlp-engineer",
                        "computer-vision-engineer","data-scientist"],
        "color_emoji": "🤖",
        "market_para": (
            "The European AI job market is expanding at an extraordinary pace. "
            "France, Switzerland, Germany, and the UK are home to world-class AI research labs and "
            "production engineering teams. Demand for AI engineers, ML engineers, and NLP specialists "
            "is outpacing supply by a significant margin — giving qualified candidates exceptional "
            "leverage in salary and work-arrangement negotiations."
        ),
        "trending_note": "LLM engineering, RAG systems, and AI safety roles are seeing the sharpest increases in job postings this quarter.",
        "hub_links": [
            ("/en/jobs/ai-engineer/remote",                "Remote AI Engineer Jobs"),
            ("/en/jobs/machine-learning-engineer/remote",  "Remote ML Engineer Jobs"),
            ("/en/jobs/nlp-engineer/remote",               "Remote NLP Engineer Jobs"),
            ("/en/jobs/ai-engineer/switzerland/remote",    "AI Engineer Jobs in Switzerland (Remote)"),
            ("/en/jobs/ai-engineer/france/remote",         "AI Engineer Jobs in France (Remote)"),
        ],
    },
    "remote-tech-jobs-europe": {
        "title":       "Remote Tech Jobs in Europe 🌍",
        "tagline":     "Fully remote and hybrid tech jobs at European companies — all roles, updated hourly.",
        "clusters":    ["software-engineering","backend-engineering","frontend-engineering",
                        "ai-ml","data-science","devops-sre","product-management"],
        "slug_filter": None,  # all slugs with remote=True
        "color_emoji": "🌍",
        "market_para": (
            "Remote work has permanently reshaped how European tech companies hire. "
            "Over 60% of software engineering roles and 72% of AI/ML positions now include "
            "a remote or hybrid option. Companies in Switzerland, France, Germany, and the Nordics "
            "are actively building remote-first teams to access the best European talent regardless of location."
        ),
        "trending_note": "Remote DevOps, AI engineering, and senior product management roles are seeing the highest month-on-month posting growth.",
        "hub_links": [
            ("/en/jobs/software-engineer/remote",          "Remote Software Engineer Jobs"),
            ("/en/jobs/full-stack-developer/remote",       "Remote Full-Stack Developer Jobs"),
            ("/en/jobs/devops-engineer/remote",            "Remote DevOps Engineer Jobs"),
            ("/en/jobs/product-manager/remote",            "Remote Product Manager Jobs"),
            ("/en/jobs/data-scientist/remote",             "Remote Data Scientist Jobs"),
        ],
    },
    "software-engineer-jobs-europe": {
        "title":       "Software Engineer Jobs in Europe 💻",
        "tagline":     "Backend, frontend, DevOps, and full-stack engineering jobs across Europe — daily updates.",
        "clusters":    ["software-engineering","backend-engineering","frontend-engineering",
                        "devops-sre","cybersecurity"],
        "slug_filter": ["software-engineer","full-stack-developer","backend-engineer",
                        "frontend-developer","devops-engineer","site-reliability-engineer",
                        "platform-engineer","kubernetes-engineer","cybersecurity-engineer"],
        "color_emoji": "💻",
        "market_para": (
            "Software engineering demand across Europe is at a sustained high. "
            "Zurich, Berlin, Paris, and Amsterdam consistently rank among the continent's top hiring cities "
            "for engineering talent. Companies are particularly hungry for cloud-native expertise, "
            "distributed systems experience, and engineers who can operate across the full stack."
        ),
        "trending_note": "Platform engineering, DevSecOps, and Kubernetes specialist roles are the fastest-growing subcategories in European software engineering hiring.",
        "hub_links": [
            ("/en/jobs/software-engineer/remote",          "Remote Software Engineer Jobs"),
            ("/en/jobs/devops-engineer/remote",            "Remote DevOps Engineer Jobs"),
            ("/en/jobs/backend-engineer/remote",           "Remote Backend Engineer Jobs"),
            ("/en/jobs/site-reliability-engineer/remote",  "Remote SRE Jobs"),
            ("/en/jobs/software-engineer/switzerland/remote", "Software Engineer Jobs Switzerland (Remote)"),
        ],
    },
    "data-jobs-europe": {
        "title":       "Data Jobs in Europe 📊",
        "tagline":     "Data engineering, analytics, and data science jobs at top European companies.",
        "clusters":    ["data-science","data-engineering","data-analytics"],
        "slug_filter": ["data-scientist","data-engineer","data-analyst",
                        "machine-learning-engineer","nlp-engineer","computer-vision-engineer"],
        "color_emoji": "📊",
        "market_para": (
            "Europe's data job market is bifurcating into two tracks: "
            "the analytics track (SQL, BI tools, business context) and the engineering track "
            "(Spark, dbt, streaming, cloud warehouses). Both tracks are in strong demand, "
            "but the engineering track commands a significant premium due to supply constraints. "
            "Switzerland and Germany are the strongest markets for senior data professionals."
        ),
        "trending_note": "Analytics engineering (dbt), real-time data pipelines (Kafka, Flink), and ML platform roles are the hottest sub-categories this quarter.",
        "hub_links": [
            ("/en/jobs/data-scientist/remote",             "Remote Data Scientist Jobs"),
            ("/en/jobs/data-engineer/remote",              "Remote Data Engineer Jobs"),
            ("/en/jobs/machine-learning-engineer/remote",  "Remote ML Engineer Jobs"),
            ("/en/jobs/data-scientist/switzerland/remote", "Data Scientist Jobs Switzerland (Remote)"),
            ("/en/jobs/data-scientist/france/remote",      "Data Scientist Jobs France (Remote)"),
        ],
    },
}

# Curated job listings per repo (these come from your live TieTalent data in production)
# For the pipeline demo we generate realistic representative entries
SAMPLE_JOBS_BY_CLUSTER = {
    "ai-ml": [
        ("AI Engineer", "Mistral AI", "Paris, France (Remote OK)", "/en/jobs/ai-engineer/remote"),
        ("LLM Engineer", "Aleph Alpha", "Heidelberg, Germany (Hybrid)", "/en/jobs/ai-engineer/germany/remote"),
        ("Applied AI Engineer", "Google DeepMind", "Zurich, Switzerland", "/en/jobs/ai-engineer/zurich"),
        ("AI Product Engineer", "Cohere", "Remote — Europe", "/en/jobs/ai-engineer/remote"),
        ("MLOps Engineer", "Hugging Face", "Paris, France (Remote OK)", "/en/jobs/ai-engineer/france/remote"),
    ],
    "data-science": [
        ("Data Scientist", "CERN", "Geneva, Switzerland", "/en/jobs/data-scientist/geneva"),
        ("Senior Data Scientist", "Booking.com", "Amsterdam, Netherlands (Remote OK)", "/en/jobs/data-scientist/remote"),
        ("ML Research Scientist", "Criteo", "Paris, France", "/en/jobs/data-scientist/paris"),
        ("NLP Engineer", "DeepL", "Cologne, Germany (Hybrid)", "/en/jobs/nlp-engineer/remote"),
        ("Applied Scientist", "Spotify", "Stockholm, Sweden (Remote OK)", "/en/jobs/data-scientist/remote"),
    ],
    "software-engineering": [
        ("Senior Software Engineer", "Doctolib", "Paris, France (Hybrid)", "/en/jobs/software-engineer/france/remote"),
        ("Staff Engineer", "N26", "Berlin, Germany (Remote OK)", "/en/jobs/software-engineer/remote"),
        ("Full-Stack Engineer", "Swissquote", "Zurich, Switzerland", "/en/jobs/full-stack-developer/zurich"),
        ("Principal Engineer", "Revolut", "Remote — Europe", "/en/jobs/software-engineer/remote"),
        ("Senior Full-Stack", "BlaBlaCar", "Paris, France (Hybrid)", "/en/jobs/full-stack-developer/france/remote"),
    ],
    "backend-engineering": [
        ("Backend Engineer (Go)", "SoundCloud", "Berlin, Germany (Remote OK)", "/en/jobs/backend-engineer/remote"),
        ("Senior Backend", "Contentful", "Berlin, Germany (Hybrid)", "/en/jobs/backend-engineer/germany/remote"),
        ("API Engineer", "Personio", "Munich, Germany (Hybrid)", "/en/jobs/backend-engineer/munich"),
        ("Platform Backend Engineer", "Celonis", "Munich, Germany (Remote OK)", "/en/jobs/backend-engineer/remote"),
        ("Backend Lead", "Zalando", "Berlin, Germany (Remote OK)", "/en/jobs/backend-engineer/remote"),
    ],
    "devops-sre": [
        ("DevOps Engineer", "Grafana Labs", "Remote — Europe", "/en/jobs/devops-engineer/remote"),
        ("Platform Engineer", "HashiCorp", "Remote — Europe", "/en/jobs/platform-engineer/remote"),
        ("SRE", "Cloudflare", "Remote — Europe", "/en/jobs/site-reliability-engineer/remote"),
        ("Kubernetes Engineer", "CERN", "Geneva, Switzerland", "/en/jobs/kubernetes-engineer/remote"),
        ("Senior SRE", "OVHcloud", "Paris, France (Hybrid)", "/en/jobs/site-reliability-engineer/france/remote"),
    ],
    "product-management": [
        ("Senior Product Manager", "Spotify", "Stockholm, Sweden (Remote OK)", "/en/jobs/product-manager/remote"),
        ("Product Lead", "Contentsquare", "Paris, France (Hybrid)", "/en/jobs/product-manager/france/remote"),
        ("Group PM", "Booking.com", "Amsterdam, Netherlands", "/en/jobs/product-manager/amsterdam"),
        ("Principal PM", "Swissquote", "Zurich, Switzerland", "/en/jobs/product-manager/zurich"),
        ("Head of Product", "ManoMano", "Paris, France (Hybrid)", "/en/jobs/product-manager/paris"),
    ],
    "data-engineering": [
        ("Data Engineer", "Zalando", "Berlin, Germany (Remote OK)", "/en/jobs/data-engineer/remote"),
        ("Analytics Engineer", "Booking.com", "Amsterdam, Netherlands (Remote OK)", "/en/jobs/data-engineer/remote"),
        ("Senior Data Engineer", "GetYourGuide", "Berlin, Germany (Hybrid)", "/en/jobs/data-engineer/germany/remote"),
        ("Data Platform Engineer", "Tamedia", "Zurich, Switzerland", "/en/jobs/data-engineer/zurich"),
        ("Staff Data Engineer", "Swisscom", "Bern, Switzerland (Hybrid)", "/en/jobs/data-engineer/bern"),
    ],
}


def freshness_header(repo_key: str, repo_cfg: dict) -> str:
    now = datetime.now(timezone.utc)
    ts  = now.strftime("%d %b %Y, %H:%M UTC")
    # Simulate freshness counts (in production: pull from live data)
    random.seed(now.hour + ord(repo_key[0]))
    new_today   = random.randint(8, 24)
    trending_up = random.randint(2, 6)
    return (
        f"> 🔥 **{new_today} new jobs added today** · "
        f"📈 **{trending_up} trending roles this week** · "
        f"🕐 **Updated {ts}**\n"
    )


def job_table(jobs: list[tuple]) -> str:
    """
    Render a markdown table: Title | Company | Location | Link
    jobs: list of (title, company, location, path)
    """
    lines = [
        "| Job Title | Company | Location | Apply |\n",
        "|-----------|---------|----------|-------|\n",
    ]
    for title, company, location, path in jobs:
        url = f"{BASE_URL}{path}"
        lines.append(f"| {title} | {company} | {location} | [View on TieTalent]({url}) |\n")
    return "".join(lines)


def generate_readme(repo_key: str, repo_cfg: dict, all_pages: list[dict]) -> str:
    # Filter pages for this repo
    clusters = set(repo_cfg["clusters"])
    slug_filter = repo_cfg.get("slug_filter")
    remote_only = repo_key == "remote-tech-jobs-europe"

    if slug_filter:
        pages = [p for p in all_pages if p["slug"] in slug_filter and p["locale"] == "en"]
    elif remote_only:
        pages = [p for p in all_pages if p.get("remote") and p["locale"] == "en"
                 and p["cluster"] in clusters]
    else:
        pages = [p for p in all_pages if p["cluster"] in clusters and p["locale"] == "en"]

    pages = sorted(pages, key=lambda x: -x.get("composite_score", 0))[:50]

    # Collect sample jobs for this repo's clusters
    curated_jobs = []
    for cl in repo_cfg["clusters"]:
        curated_jobs.extend(SAMPLE_JOBS_BY_CLUSTER.get(cl, []))
    # Deduplicate and take top 12
    seen_titles = set()
    unique_jobs = []
    for j in curated_jobs:
        if j[0] not in seen_titles:
            seen_titles.add(j[0]); unique_jobs.append(j)
    recent_jobs  = unique_jobs[:5]
    top_jobs     = unique_jobs[5:12] if len(unique_jobs) > 5 else unique_jobs

    ts = datetime.now(timezone.utc)
    week_str = ts.strftime("Week of %d %b %Y")

    hub_section = "\n".join(
        f"- [{label}]({BASE_URL}{path})"
        for path, label in repo_cfg["hub_links"]
    )

    # All pages as a compact linked list
    all_links = "\n".join(
        f"- [{' '.join(w.capitalize() for w in p['slug'].split('-'))} "
        f"{'— ' + (p.get('location_label') or p.get('location','').title()) if p.get('location') else ''}"
        f"{'(Remote)' if p.get('remote') else ''}]({BASE_URL}{p['pretty_url']})"
        for p in pages[:30]
    )

    readme = f"""# {repo_cfg['title']}

> {repo_cfg['tagline']}

{freshness_header(repo_key, repo_cfg)}

**[→ See all jobs on TieTalent]({BASE_URL}/en/jobs)** · **[Create your free profile]({BASE_URL}/register)**

---

## 🔥 Top Jobs This Week ({week_str})

{job_table(top_jobs)}

---

## 🆕 Recently Added

{job_table(recent_jobs)}

---

## 🌍 Browse by Role

{hub_section}

---

## 📋 All Job Pages

{all_links}

---

## 📈 Market Insights

{repo_cfg['market_para']}

> **Trending now:** {repo_cfg['trending_note']}

---

## About TieTalent

TieTalent is Europe's **reverse job platform** for tech professionals.

Instead of applying to dozens of companies, you create one profile and **companies apply to you** — filtered by your skills, experience, location preferences, and work arrangement.

- 🇨🇭 Strong in Switzerland (Zurich, Geneva, Lausanne, Basel)
- 🇫🇷 Growing in France (Paris, Lyon)
- 🇩🇪 Active in Germany (Berlin, Munich, Hamburg)
- 🇳🇱 Present in the Netherlands (Amsterdam)
- 🌍 Remote-first roles across Europe

**[Create your free TieTalent profile →]({BASE_URL}/register)**

---

*This repository is updated automatically every hour by the [TieTalent SEO pipeline](https://github.com/tietalent/seo-pages).
Last updated: {ts.strftime('%Y-%m-%d %H:%M UTC')}*
"""
    return readme


def main():
    # Load tier1 pages
    t1_path = DATA_DIR / "tier1_pages.json"
    if not t1_path.exists():
        log.error("Run 07 first!"); return
    with open(t1_path, encoding="utf-8") as f:
        all_pages = json.load(f)

    for repo_key, repo_cfg in REPOS.items():
        repo_dir = REPOS_DIR / repo_key
        repo_dir.mkdir(parents=True, exist_ok=True)

        readme = generate_readme(repo_key, repo_cfg, all_pages)
        (repo_dir / "README.md").write_text(readme, encoding="utf-8")
        log.info(f"✓ {repo_key}/README.md ({len(readme.splitlines())} lines)")

        # Write a minimal .github/workflows/update.yml for each repo
        wf_dir = repo_dir / ".github" / "workflows"
        wf_dir.mkdir(parents=True, exist_ok=True)
        workflow = f"""name: Update job listings

on:
  schedule:
    - cron: '0 * * * *'   # Every hour
  workflow_dispatch:

jobs:
  update:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: {{python-version: '3.11'}}
      - name: Regenerate README
        run: |
          pip install requests
          python scripts/generate_{repo_key.replace('-','_')}.py
      - uses: stefanzweifel/git-auto-commit-action@v5
        with:
          commit_message: "chore: refresh job listings [hourly]"
          file_pattern: "README.md"
"""
        (wf_dir / "update.yml").write_text(workflow, encoding="utf-8")

        # Minimal repo description file
        meta = {
            "repo_key":    repo_key,
            "clusters":    repo_cfg["clusters"],
            "description": repo_cfg["tagline"],
            "last_updated": datetime.now(timezone.utc).isoformat(),
        }
        (repo_dir / "meta.json").write_text(
            json.dumps(meta, indent=2), encoding="utf-8"
        )

    log.info(f"✓ {len(REPOS)} repos generated → {REPOS_DIR}")


if __name__ == "__main__":
    main()
