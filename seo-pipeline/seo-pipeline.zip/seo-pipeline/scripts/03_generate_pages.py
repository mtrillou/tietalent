#!/usr/bin/env python3
"""
Step 3 + 4: Generate SEO page definitions.
Input:  data/normalized_jobs.json
        data/priority_locations.json
Output: data/page_definitions.json   — full list of pages to create
        data/url_map.json             — new URL → internal URL mapping
"""

import json
import logging
from pathlib import Path
from itertools import product as cartesian_product

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)

DATA_DIR = Path(__file__).parent.parent / "data"

# ---------------------------------------------------------------------------
# Priority config: which combinations to create
# ---------------------------------------------------------------------------
# Tier 1 locations get all combos; tier 2 only country-level pages
COMBO_RULES = {
    "tier1_location": ["core", "location", "remote", "location_remote"],
    "tier2_location": ["core", "location"],
    "remote_only":    ["core", "remote"],
}

# Only generate combination pages for high-SEO-score slugs (≥ threshold)
MIN_SEO_SCORE_FOR_COMBOS = 40.0
MIN_SEO_SCORE_FOR_TIER2  = 60.0


def build_internal_url(slug: str, location_slug: str | None = None, remote: bool = False) -> str:
    """Map pretty URL → existing /jobs/search/... backend."""
    base = f"/jobs/search/{slug}/all"
    params = []
    if location_slug and location_slug != "remote":
        params.append(f"location={location_slug}")
    if remote or location_slug == "remote":
        params.append("remote=true")
    if params:
        return f"{base}?{'&'.join(params)}"
    return base


def build_pretty_url(locale: str, slug: str, location_slug: str | None = None, remote: bool = False) -> str:
    """Generate human-readable SEO URL."""
    base = f"/{locale}/jobs/{slug}"
    if location_slug and location_slug != "remote":
        base += f"/{location_slug}"
    if remote or location_slug == "remote":
        base += "/remote"
    return base


def page_type(location_slug: str | None, remote: bool) -> str:
    if not location_slug and not remote:
        return "core"
    if location_slug and not remote:
        return "location"
    if not location_slug and remote:
        return "remote"
    return "location_remote"


def generate_pages(records: list[dict], locations: list[dict]) -> list[dict]:
    pages = []
    seen_urls: set[str] = set()

    # Group records by slug (we need all locales per slug)
    slug_records: dict[str, list] = {}
    for r in records:
        slug_records.setdefault(r["slug"], []).append(r)

    for slug, slug_recs in slug_records.items():
        locales = {r["locale"] for r in slug_recs}
        seo_score = max(r.get("seo_score", 0) for r in slug_recs)
        cluster = slug_recs[0].get("cluster", "other")
        job_title = slug_recs[0]["job_title_normalized"]
        available_locales = sorted(locales)

        for locale in available_locales:
            # --- Core page (always generated) ---
            pretty = build_pretty_url(locale, slug)
            internal = build_internal_url(slug)
            if pretty not in seen_urls:
                seen_urls.add(pretty)
                pages.append({
                    "type": "core",
                    "pretty_url": pretty,
                    "internal_url": internal,
                    "locale": locale,
                    "slug": slug,
                    "job_title": job_title,
                    "location": None,
                    "remote": False,
                    "cluster": cluster,
                    "seo_score": seo_score,
                    "available_locales": available_locales,
                    "alternate_urls": {},  # populated below
                })

            # --- Skip combos for low-score pages ---
            if seo_score < MIN_SEO_SCORE_FOR_COMBOS:
                continue

            # --- Remote page ---
            pretty = build_pretty_url(locale, slug, remote=True)
            internal = build_internal_url(slug, remote=True)
            if pretty not in seen_urls:
                seen_urls.add(pretty)
                pages.append({
                    "type": "remote",
                    "pretty_url": pretty,
                    "internal_url": internal,
                    "locale": locale,
                    "slug": slug,
                    "job_title": job_title,
                    "location": "remote",
                    "remote": True,
                    "cluster": cluster,
                    "seo_score": seo_score * 0.9,
                    "available_locales": available_locales,
                    "alternate_urls": {},
                })

            # --- Location combo pages ---
            for loc in locations:
                loc_slug = loc["slug"]
                loc_tier = loc["tier"]
                if loc_slug == "remote":
                    continue  # handled above

                # Skip tier 2 for lower-score jobs
                if loc_tier == 2 and seo_score < MIN_SEO_SCORE_FOR_TIER2:
                    continue

                # Location-only page
                pretty = build_pretty_url(locale, slug, loc_slug)
                internal = build_internal_url(slug, loc_slug)
                if pretty not in seen_urls:
                    seen_urls.add(pretty)
                    pages.append({
                        "type": "location",
                        "pretty_url": pretty,
                        "internal_url": internal,
                        "locale": locale,
                        "slug": slug,
                        "job_title": job_title,
                        "location": loc_slug,
                        "location_label": loc["label"],
                        "remote": False,
                        "cluster": cluster,
                        "seo_score": seo_score * 0.85,
                        "available_locales": available_locales,
                        "alternate_urls": {},
                    })

                # Location + remote page (tier 1 only)
                if loc_tier == 1:
                    pretty = build_pretty_url(locale, slug, loc_slug, remote=True)
                    internal = build_internal_url(slug, loc_slug, remote=True)
                    if pretty not in seen_urls:
                        seen_urls.add(pretty)
                        pages.append({
                            "type": "location_remote",
                            "pretty_url": pretty,
                            "internal_url": internal,
                            "locale": locale,
                            "slug": slug,
                            "job_title": job_title,
                            "location": loc_slug,
                            "location_label": loc["label"],
                            "remote": True,
                            "cluster": cluster,
                            "seo_score": seo_score * 0.75,
                            "available_locales": available_locales,
                            "alternate_urls": {},
                        })

    # Build hreflang alternate URLs
    # Group by (slug, location, remote) → map locale → pretty_url
    from collections import defaultdict
    alt_key_map: dict[tuple, dict] = defaultdict(dict)
    for p in pages:
        key = (p["slug"], p.get("location"), p["remote"])
        alt_key_map[key][p["locale"]] = p["pretty_url"]

    for p in pages:
        key = (p["slug"], p.get("location"), p["remote"])
        p["alternate_urls"] = {
            loc: url for loc, url in alt_key_map[key].items()
            if loc != p["locale"]
        }

    log.info(f"Generated {len(pages)} page definitions")
    return pages


def build_url_map(pages: list[dict]) -> dict:
    """pretty_url → internal_url lookup."""
    return {p["pretty_url"]: p["internal_url"] for p in pages}


def main():
    norm_path = DATA_DIR / "normalized_jobs.json"
    if not norm_path.exists():
        log.error("Run 01 and 02 scripts first!")
        return

    with open(norm_path, encoding="utf-8") as f:
        records = json.load(f)
    with open(DATA_DIR / "priority_locations.json", encoding="utf-8") as f:
        locations = json.load(f)

    pages = generate_pages(records, locations)

    # Sort by SEO score desc
    pages.sort(key=lambda p: -p["seo_score"])

    out_pages = DATA_DIR / "page_definitions.json"
    with open(out_pages, "w", encoding="utf-8") as f:
        json.dump(pages, f, indent=2, ensure_ascii=False)
    log.info(f"✓ Saved {len(pages)} page definitions → {out_pages}")

    url_map = build_url_map(pages)
    out_map = DATA_DIR / "url_map.json"
    with open(out_map, "w", encoding="utf-8") as f:
        json.dump(url_map, f, indent=2, ensure_ascii=False)
    log.info(f"✓ url_map.json → {len(url_map)} entries")

    # Stats by type
    from collections import Counter
    type_counts = Counter(p["type"] for p in pages)
    log.info("=== Page breakdown ===")
    for t, c in type_counts.most_common():
        log.info(f"  {t}: {c}")

    return pages


if __name__ == "__main__":
    main()
