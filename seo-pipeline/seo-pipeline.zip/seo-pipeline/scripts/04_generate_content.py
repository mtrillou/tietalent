#!/usr/bin/env python3
"""
Step 5: Generate SEO content for each page.
Input:  data/page_definitions.json
Output: pages/{locale}/{slug}[/{location}][/remote]/content.json
"""

import json
import logging
import random
from pathlib import Path
from string import Template

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)

DATA_DIR  = Path(__file__).parent.parent / "data"
PAGES_DIR = Path(__file__).parent.parent / "pages"

# ---------------------------------------------------------------------------
# Localized string templates
# ---------------------------------------------------------------------------
TEMPLATES = {
    "en": {
        "title_core":             "Find {title_cap} Jobs | TieTalent",
        "title_location":         "{title_cap} Jobs in {location_label} | TieTalent",
        "title_remote":           "Remote {title_cap} Jobs | TieTalent",
        "title_location_remote":  "Remote {title_cap} Jobs in {location_label} | TieTalent",

        "meta_core":              "Browse {title} job openings on TieTalent. Find your next {title} role and apply directly with your profile.",
        "meta_location":          "Explore {title} jobs in {location_label}. Compare salaries, company reviews, and apply instantly on TieTalent.",
        "meta_remote":            "Find remote {title} positions across Europe. Work from anywhere — browse the best remote {title} jobs on TieTalent.",
        "meta_location_remote":   "Remote {title} jobs based in {location_label}. Flexible work options for {title} professionals on TieTalent.",

        "h1_core":                "{title_cap} Jobs",
        "h1_location":            "{title_cap} Jobs in {location_label}",
        "h1_remote":              "Remote {title_cap} Jobs",
        "h1_location_remote":     "Remote {title_cap} Jobs in {location_label}",

        "intro_core": """\
Are you a {title} looking for your next opportunity? TieTalent connects talented professionals with top companies across Europe and beyond. \
Our platform hosts hundreds of active {title} openings, from seed-stage startups to global enterprises, allowing you to browse, compare, and apply with a single profile.\n\n\
Unlike traditional job boards, TieTalent reverses the process: after you create your profile, companies apply to you — saving you hours of outreach. \
As a {title}, you deserve to find a role that matches your skills, values, and salary expectations.\n\n\
Use our filters to narrow by location, seniority, tech stack, and remote flexibility. New {title} roles are posted daily, so check back often or activate instant alerts.\
""",

        "intro_location": """\
Looking for {title} jobs in {location_label}? TieTalent aggregates the best {title} opportunities from top employers across {location_label}, \
giving you direct access to roles that often aren't advertised elsewhere.\n\n\
{location_label} is home to a thriving tech and business ecosystem, making it one of Europe's premier destinations for {title} professionals. \
From multinational corporations to agile startups, the demand for {title} talent in {location_label} continues to grow year over year.\n\n\
Create your free TieTalent profile today to get discovered by {location_label}-based companies actively hiring for {title} positions.\
""",

        "intro_remote": """\
Remote work has permanently changed the way {title} professionals build their careers. TieTalent's remote {title} job board connects you with companies \
that offer full flexibility — whether you want 100% remote, hybrid, or location-independent contracts.\n\n\
Thousands of companies are now hiring {title} candidates who can work from anywhere in Europe or globally. \
By creating your TieTalent profile, you'll be visible to remote-first employers looking for exactly your expertise.\n\n\
Stop scrolling dozens of job boards — TieTalent's smart matching engine surfaces the most relevant remote {title} roles based on your skills and preferences.\
""",

        "intro_location_remote": """\
Remote {title} opportunities in {location_label} offer the best of both worlds: the flexibility to work from home while staying connected to {location_label}'s \
vibrant professional network. Many companies in {location_label} now offer hybrid or fully remote contracts for {title} roles.\n\n\
TieTalent makes it easy to filter specifically for remote-friendly {title} positions headquartered or operating in {location_label}. \
Browse current openings, compare compensation, and apply directly through your TieTalent profile.\
""",

        "faq": [
            {"q": "How many {title} jobs are currently available?",
             "a": "TieTalent lists hundreds of active {title} openings updated daily. Create a free profile to see all matching opportunities and get instant alerts."},
            {"q": "What salary can a {title} expect{location_suffix}?",
             "a": "Salaries for {title} professionals{location_suffix} vary widely by seniority, industry, and company size. TieTalent shows transparent salary bands on each listing."},
            {"q": "Do I need to apply separately to each {title} position?",
             "a": "No — with TieTalent you create one profile and companies come to you. Simply set your preferences and let our matching engine do the work."},
            {"q": "Can I find remote {title} jobs{location_suffix} on TieTalent?",
             "a": "Yes. Use our 'Remote' filter to view {title} positions with flexible or fully remote work arrangements{location_suffix}."},
        ],
    },

    "fr": {
        "title_core":             "Offres d'emploi {title_cap} | TieTalent",
        "title_location":         "Emplois {title_cap} à {location_label} | TieTalent",
        "title_remote":           "Emplois {title_cap} en télétravail | TieTalent",
        "title_location_remote":  "Télétravail {title_cap} à {location_label} | TieTalent",

        "meta_core":              "Trouvez des offres d'emploi {title} sur TieTalent. Postulez directement avec votre profil et laissez les entreprises venir à vous.",
        "meta_location":          "Découvrez les meilleures offres {title} à {location_label} sur TieTalent. Comparez les salaires et postulez en un clic.",
        "meta_remote":            "Emplois {title} en télétravail partout en Europe. Travaillez où vous voulez avec TieTalent.",
        "meta_location_remote":   "Offres {title} en télétravail basées à {location_label}. Flexibilité maximale avec TieTalent.",

        "h1_core":                "Offres d'emploi {title_cap}",
        "h1_location":            "Emplois {title_cap} à {location_label}",
        "h1_remote":              "Emplois {title_cap} en télétravail",
        "h1_location_remote":     "{title_cap} en télétravail à {location_label}",

        "intro_core": """\
Vous êtes {title} et vous recherchez une nouvelle opportunité professionnelle ? TieTalent met en relation les professionnels talentueux avec les meilleures entreprises \
d'Europe. Notre plateforme recense des centaines d'offres {title} actives, des startups en pleine croissance aux grands groupes internationaux.\n\n\
Contrairement aux jobboards traditionnels, TieTalent inverse le processus : créez votre profil et laissez les entreprises vous contacter. \
Filtrez par localisation, séniorité, secteur et télétravail pour trouver le poste idéal.\
""",

        "intro_location": """\
Vous cherchez un emploi {title} à {location_label} ? TieTalent centralise les meilleures offres des employeurs de {location_label}, \
vous donnant accès à des postes souvent non publiés ailleurs.\n\n\
{location_label} bénéficie d'un écosystème économique dynamique, attirant des talents {title} du monde entier. \
Créez votre profil gratuitement pour être visible auprès des recruteurs actifs à {location_label}.\
""",

        "intro_remote": """\
Le télétravail a transformé la façon dont les professionnels {title} construisent leur carrière. \
TieTalent référence les meilleures offres {title} en full remote, hybride ou nomade digital.\n\n\
Des milliers d'entreprises recherchent des profils {title} capables de travailler à distance. \
Créez votre profil TieTalent pour être découvert par ces employeurs.\
""",

        "intro_location_remote": """\
Les opportunités {title} en télétravail à {location_label} combinent flexibilité et ancrage local. \
De nombreuses entreprises de {location_label} proposent désormais des contrats hybrides ou full remote pour les postes {title}.\n\n\
Filtrez spécifiquement les offres remote-friendly sur TieTalent et postulez directement via votre profil.\
""",

        "faq": [
            {"q": "Combien d'offres {title} sont disponibles actuellement ?",
             "a": "TieTalent liste des centaines d'offres {title} mises à jour quotidiennement. Créez un profil gratuit pour voir toutes les correspondances."},
            {"q": "Quel salaire peut espérer un {title}{location_suffix} ?",
             "a": "Les salaires {title}{location_suffix} varient selon le niveau, le secteur et la taille de l'entreprise. TieTalent affiche les fourchettes salariales sur chaque offre."},
            {"q": "Dois-je postuler séparément à chaque offre {title} ?",
             "a": "Non — avec TieTalent, vous créez un seul profil et les entreprises vous contactent directement."},
            {"q": "Peut-on trouver des postes {title} en télétravail{location_suffix} ?",
             "a": "Oui, utilisez le filtre « Télétravail » pour afficher les offres {title} avec flexibilité de lieu{location_suffix}."},
        ],
    },

    "de": {
        "title_core":             "{title_cap} Jobs | TieTalent",
        "title_location":         "{title_cap} Jobs in {location_label} | TieTalent",
        "title_remote":           "Remote {title_cap} Jobs | TieTalent",
        "title_location_remote":  "Remote {title_cap} Jobs in {location_label} | TieTalent",

        "meta_core":              "Finde aktuelle {title} Stellenangebote auf TieTalent. Bewirb dich direkt mit deinem Profil und werde von Top-Unternehmen entdeckt.",
        "meta_location":          "{title} Jobs in {location_label} — vergleiche Gehälter und bewirb dich mit einem Klick auf TieTalent.",
        "meta_remote":            "Remote {title} Stellen europaweit. Arbeite flexibel von überall mit TieTalent.",
        "meta_location_remote":   "Remote {title} Stellen in {location_label}. Maximale Flexibilität für {title}-Fachkräfte auf TieTalent.",

        "h1_core":                "{title_cap} Jobs",
        "h1_location":            "{title_cap} Jobs in {location_label}",
        "h1_remote":              "Remote {title_cap} Jobs",
        "h1_location_remote":     "Remote {title_cap} Jobs in {location_label}",

        "intro_core": """\
Du bist {title} und suchst eine neue Stelle? TieTalent verbindet qualifizierte Fachkräfte mit den besten Arbeitgebern in Europa. \
Auf unserer Plattform findest du täglich neue {title}-Stellenangebote — von innovativen Startups bis zu globalen Konzernen.\n\n\
Mit TieTalent erstellst du einmal ein Profil und Unternehmen bewerben sich bei dir — das spart Zeit und steigert deine Chancen erheblich. \
Filtere nach Standort, Seniorität und Remote-Optionen.\
""",

        "intro_location": """\
Suchst du einen {title} Job in {location_label}? TieTalent bündelt die besten Stellenangebote von Arbeitgebern aus {location_label} \
und bietet dir Zugang zu Stellen, die oft nicht öffentlich ausgeschrieben werden.\n\n\
{location_label} ist ein attraktiver Standort für {title}-Fachkräfte mit wachsender Nachfrage. \
Erstelle jetzt dein kostenloses TieTalent-Profil und werde von Unternehmen in {location_label} gefunden.\
""",

        "intro_remote": """\
Remote-Arbeit hat die Karrieremöglichkeiten für {title}-Fachkräfte revolutioniert. TieTalent listet die besten Remote-{title}-Stellen \
von Unternehmen, die volle Flexibilität bieten.\n\n\
Tausende Firmen suchen {title}-Kandidaten, die remote oder hybrid arbeiten können. \
Erstelle dein Profil auf TieTalent und lass dich von remote-freundlichen Arbeitgebern entdecken.\
""",

        "intro_location_remote": """\
Remote {title} Stellen in {location_label} bieten das Beste aus beiden Welten: Flexibilität und Zugang zum lokalen Netzwerk. \
Immer mehr Unternehmen in {location_label} bieten Hybrid- oder Full-Remote-Verträge für {title}-Positionen an.\n\n\
Nutze TieTalent, um gezielt remote-freundliche {title} Stellen in {location_label} zu finden.\
""",

        "faq": [
            {"q": "Wie viele {title} Stellen sind aktuell verfügbar?",
             "a": "TieTalent listet täglich aktualisierte {title} Stellenangebote. Erstelle ein kostenloses Profil für alle passenden Angebote."},
            {"q": "Welches Gehalt kann ein {title}{location_suffix} erwarten?",
             "a": "Gehälter für {title}{location_suffix} variieren je nach Erfahrung, Branche und Unternehmensgröße. TieTalent zeigt transparente Gehaltsbänder."},
            {"q": "Muss ich mich bei jeder {title} Stelle einzeln bewerben?",
             "a": "Nein — bei TieTalent erstellst du einmal ein Profil und Unternehmen bewerben sich bei dir."},
            {"q": "Gibt es Remote {title} Stellen{location_suffix} auf TieTalent?",
             "a": "Ja, nutze den Remote-Filter für {title} Stellen mit flexibler Arbeitsweise{location_suffix}."},
        ],
    },
}


def render_content(page: dict) -> dict:
    locale = page["locale"]
    t = TEMPLATES.get(locale, TEMPLATES["en"])
    page_type = page["type"]

    job_title = page["job_title"]
    title_cap = " ".join(w.capitalize() for w in job_title.split())
    location_label = page.get("location_label", page.get("location") or "")
    location_suffix = f" in {location_label}" if location_label and location_label != "remote" else ""

    ctx = {
        "title": job_title,
        "title_cap": title_cap,
        "location_label": location_label,
        "location_suffix": location_suffix,
    }

    def r(tmpl_str: str) -> str:
        return tmpl_str.format(**ctx)

    title_tag   = r(t[f"title_{page_type}"])
    meta_desc   = r(t[f"meta_{page_type}"])
    h1          = r(t[f"h1_{page_type}"])
    intro       = r(t[f"intro_{page_type}"])

    faq_items = []
    for item in t["faq"]:
        faq_items.append({
            "question": r(item["q"]),
            "answer":   r(item["a"]),
        })

    faq_schema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": faq["question"],
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": faq["answer"],
                },
            }
            for faq in faq_items
        ],
    }

    return {
        "pretty_url":       page["pretty_url"],
        "internal_url":     page["internal_url"],
        "locale":           locale,
        "type":             page_type,
        "slug":             page["slug"],
        "location":         page.get("location"),
        "remote":           page["remote"],
        "cluster":          page["cluster"],
        "seo_score":        page["seo_score"],
        "alternate_urls":   page.get("alternate_urls", {}),
        "content": {
            "title_tag":    title_tag,
            "meta_description": meta_desc,
            "h1":           h1,
            "intro":        intro,
            "faq":          faq_items,
            "faq_schema":   faq_schema,
        },
    }


def main():
    src = DATA_DIR / "page_definitions.json"
    if not src.exists():
        log.error("Run 03 first!")
        return

    with open(src, encoding="utf-8") as f:
        pages = json.load(f)

    rendered = []
    for page in pages:
        rendered.append(render_content(page))

    # Write all rendered content
    out = DATA_DIR / "rendered_pages.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rendered, f, indent=2, ensure_ascii=False)
    log.info(f"✓ Rendered {len(rendered)} pages → {out}")

    # Also write sample pages (first 5)
    samples_dir = PAGES_DIR / "samples"
    samples_dir.mkdir(parents=True, exist_ok=True)
    for page in rendered[:5]:
        slug_safe = page["pretty_url"].replace("/", "_").strip("_")
        out_path = samples_dir / f"{slug_safe}.json"
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(page, f, indent=2, ensure_ascii=False)
    log.info(f"✓ 5 sample pages → {samples_dir}")


if __name__ == "__main__":
    main()
