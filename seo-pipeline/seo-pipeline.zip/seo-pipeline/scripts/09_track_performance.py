#!/usr/bin/env python3
"""
09_track_performance.py V3 — Active weekly iteration loop. No passive waiting.
GSC data → 4 concrete action buckets every run:
  1. LOW CTR (high impressions, low clicks) → rewrite title/meta
  2. NOT INDEXED (zero impressions)         → fix content/links
  3. WINNER (clicks≥10, pos≤15)             → expand variants
  4. PROMISING (clicks≥3, pos 16-30)        → add internal links
"""
import json, csv, logging, argparse, random
from pathlib import Path
from datetime import date

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
log = logging.getLogger(__name__)
DATA_DIR    = Path(__file__).parent.parent / "data"
REPORTS_DIR = Path(__file__).parent.parent / "reports"
REPORTS_DIR.mkdir(exist_ok=True)
BASE_URL = "https://tietalent.com"

def classify(m):
    imp,cli,pos,ctr=m["impressions"],m["clicks"],m["position"],m["ctr"]
    if imp==0:                        return "not_indexed"
    if cli>=10 and pos<=15:           return "winner"
    if cli>=3 and 15<pos<=30:         return "promising"
    if imp>=100 and cli<=2 and pos>=30: return "underperformer"
    if imp>=50 and ctr<0.02:          return "low_ctr"
    return "monitoring"

def action_low_ctr(p):
    m=p["gsc"]
    return {"type":"rewrite_meta","url":p["pretty_url"],"priority":"high",
        "reason":f"High impressions ({m['impressions']}) but low CTR ({m['ctr']:.1%}) at pos {m['position']:.1f}",
        "action":"Rewrite title tag: add stronger hook, add 'Remote' if applicable, add tech stack specifics. Rewrite meta description with a clear differentiator vs generic job boards. Target CTR >3.5%."}

def action_not_indexed(p):
    return {"type":"fix_indexing","url":p["pretty_url"],"priority":"high" if p.get("tier")==1 else "medium",
        "reason":"Zero impressions — page may not be indexed or content is too thin.",
        "action":"1. Check robots.txt + noindex tags. 2. Add 3+ internal links from hub/core pages. 3. Enrich intro paragraph + add FAQ schema. 4. Submit via GSC URL Inspection."}

def action_winner(p):
    m=p["gsc"]
    return {"type":"expand_winner","url":p["pretty_url"],"priority":"high",
        "reason":f"Strong performer: {m['clicks']} clicks, position {m['position']:.1f}",
        "action":f"Expand '{p['slug']}': (1) add missing Tier-1 city variants. (2) add FR/DE locale versions. (3) add to hub page as featured link. (4) build 3-5 new internal links from Tier-2 pages in cluster '{p['cluster']}'."}

def action_promising(p):
    m=p["gsc"]
    return {"type":"boost_links","url":p["pretty_url"],"priority":"medium",
        "reason":f"Ranking {m['position']:.1f}, {m['clicks']} clicks — needs link authority",
        "action":"Add 3-5 internal links from: (1) cluster hub page. (2) 2 related core pages. (3) 1 high-authority page. Also add to relevant GitHub repo README job table."}

def mock_gsc(pages):
    random.seed(42); out={}
    for p in pages:
        sc=p.get("composite_score",50); tier=p.get("tier",3)
        if tier==1 and random.random()>0.15:
            impr=int(sc*random.uniform(6,22)); cli=int(impr*random.uniform(0.015,0.10))
            pos=round(max(3,random.gauss(25,18)),1)
        elif tier==2 and random.random()>0.4:
            impr=int(sc*random.uniform(1,5)); cli=int(impr*random.uniform(0.005,0.04))
            pos=round(random.uniform(25,70),1)
        else: impr=cli=0; pos=0.0
        out[p["pretty_url"]]={"clicks":cli,"impressions":impr,
            "ctr":round(cli/impr,4) if impr else 0.0,"position":pos}
    return out

def load_csv(path):
    out={}
    with open(path,encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            page=row.get("page","").replace(BASE_URL,"")
            out[page]={"clicks":int(float(row.get("clicks",0))),
                "impressions":int(float(row.get("impressions",0))),
                "ctr":float(str(row.get("ctr","0")).strip("%").replace(",","."))/100,
                "position":float(row.get("position",0))}
    return out

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--gsc",type=Path); parser.add_argument("--demo",action="store_true")
    args=parser.parse_args()
    scored=json.load(open(DATA_DIR/"scored_pages.json",encoding="utf-8"))
    gsc_data = load_csv(args.gsc) if (args.gsc and args.gsc.exists()) else mock_gsc(scored)
    if not (args.gsc and args.gsc.exists()):
        mock_out=DATA_DIR/"gsc_export_sample.csv"
        with open(mock_out,"w",newline="",encoding="utf-8") as f:
            w=csv.writer(f); w.writerow(["page","clicks","impressions","ctr","position"])
            for url,m in gsc_data.items():
                w.writerow([f"{BASE_URL}{url}",m["clicks"],m["impressions"],f"{m['ctr']:.4f}",f"{m['position']:.1f}"])
    by_class={}; actions=[]
    for p in scored:
        m=gsc_data.get(p["pretty_url"],{"clicks":0,"impressions":0,"ctr":0.0,"position":0.0})
        p["gsc"]=m; cls=classify(m); p["performance_class"]=cls
        p["traffic_score"]=min(int(m["clicks"]*2+m["impressions"]*0.1+max(0,50-m["position"])),100)
        by_class.setdefault(cls,[]).append(p)
        if p.get("tier",3)<=2:
            if cls=="low_ctr":     actions.append(action_low_ctr(p))
            elif cls=="not_indexed": actions.append(action_not_indexed(p))
            elif cls=="winner":    actions.append(action_winner(p))
            elif cls=="promising": actions.append(action_promising(p))
    prio={"high":0,"medium":1,"low":2}
    actions.sort(key=lambda x:prio.get(x["priority"],2))
    json.dump(scored,open(DATA_DIR/"scored_pages_with_gsc.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    json.dump(actions,open(DATA_DIR/"action_items.json","w",encoding="utf-8"),indent=2,ensure_ascii=False)
    log.info("=== GSC Summary ===")
    for cls in ["winner","promising","low_ctr","underperformer","not_indexed","monitoring"]:
        log.info(f"  {cls:<20}: {len(by_class.get(cls,[]))}")
    log.info(f"  Action items: {len(actions)}")
    today=date.today().isoformat()
    lines=[f"# SEO Performance Report — {today}\n\n","## Summary\n\n",
           "| Class | Pages | Action |\n|-------|-------|--------|\n"]
    am={"winner":"→ Expand variants","promising":"→ Add internal links","low_ctr":"→ Rewrite title/meta",
        "underperformer":"→ Improve content","not_indexed":"→ Fix indexing","monitoring":"→ Watch"}
    for cls in ["winner","promising","low_ctr","underperformer","not_indexed","monitoring"]:
        lines.append(f"| {cls} | {len(by_class.get(cls,[]))} | {am.get(cls,'—')} |\n")
    lines+=["\n## 🏆 Winners\n\n","| URL | Clicks | Pos |\n|-----|--------|-----|\n"]
    for p in sorted(by_class.get("winner",[]),key=lambda x:-x["gsc"]["clicks"])[:10]:
        lines.append(f"| `{p['pretty_url']}` | {p['gsc']['clicks']} | {p['gsc']['position']} |\n")
    lines+=["\n## 🔧 Low CTR (rewrite meta)\n\n","| URL | Impr | CTR | Pos |\n|-----|------|-----|-----|\n"]
    for p in sorted(by_class.get("low_ctr",[]),key=lambda x:-x["gsc"]["impressions"])[:10]:
        m=p["gsc"]; lines.append(f"| `{p['pretty_url']}` | {m['impressions']} | {m['ctr']:.1%} | {m['position']:.1f} |\n")
    lines+=["\n## 🔗 Promising (need links)\n\n","| URL | Clicks | Pos |\n|-----|--------|-----|\n"]
    for p in sorted(by_class.get("promising",[]),key=lambda x:x["gsc"]["position"])[:10]:
        lines.append(f"| `{p['pretty_url']}` | {p['gsc']['clicks']} | {p['gsc']['position']} |\n")
    lines+=["\n## ❌ Not Indexed\n\n"]
    for p in [x for x in by_class.get("not_indexed",[]) if x.get("tier",3)<=2][:10]:
        lines.append(f"- `{p['pretty_url']}` (T{p.get('tier',2)})\n")
    rpath=REPORTS_DIR/f"performance_{today}.md"
    rpath.write_text("".join(lines),encoding="utf-8")
    (REPORTS_DIR/"performance_latest.md").write_text("".join(lines),encoding="utf-8")
    log.info(f"✓ {rpath.name}")

if __name__=="__main__": main()
