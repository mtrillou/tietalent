#!/usr/bin/env python3
"""
Master pipeline: runs all steps in sequence.
Usage:
  python run_pipeline.py                  # full run
  python run_pipeline.py --steps 1,2,3    # specific steps
  python run_pipeline.py --mock           # use mock data (no network)
"""

import sys
import logging
import argparse
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("pipeline.log"),
    ]
)
log = logging.getLogger(__name__)

# Add scripts dir to path
sys.path.insert(0, str(Path(__file__).parent / "scripts"))

STEPS = {
    1: ("Parse Sitemaps",       "01_parse_sitemaps",    "main"),
    2: ("Normalize & Cluster",  "02_normalize_cluster", "main"),
    3: ("Generate Pages",       "03_generate_pages",    "main"),
    4: ("Generate Content",     "04_generate_content",  "main"),
    5: ("Build Link Graph",     "05_build_links",       "main"),
    6: ("Generate Sitemaps",    "06_generate_sitemaps", "main"),
}


def run(steps: list[int]):
    import importlib
    for step_num in steps:
        name, module, fn = STEPS[step_num]
        log.info(f"{'='*60}")
        log.info(f"STEP {step_num}: {name}")
        log.info(f"{'='*60}")
        try:
            mod = importlib.import_module(module)
            getattr(mod, fn)()
            log.info(f"✓ Step {step_num} complete\n")
        except Exception as e:
            log.error(f"✗ Step {step_num} failed: {e}")
            raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", help="Comma-separated step numbers, e.g. 1,2,3")
    parser.add_argument("--mock",  action="store_true", help="Skip live sitemap fetch")
    args = parser.parse_args()

    if args.mock:
        # Skip step 1, start from step 2 using mock data generated inside step 2
        steps = [2, 3, 4, 5, 6]
    elif args.steps:
        steps = [int(s) for s in args.steps.split(",")]
    else:
        steps = list(STEPS.keys())

    log.info(f"Running steps: {steps}")
    run(steps)
    log.info("Pipeline complete ✓")


if __name__ == "__main__":
    main()
