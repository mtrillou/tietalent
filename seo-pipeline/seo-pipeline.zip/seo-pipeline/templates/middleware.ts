/**
 * Next.js middleware — URL rewriting & canonical enforcement.
 * File: middleware.ts (project root)
 *
 * Responsibilities:
 * 1. Rewrite new pretty SEO URLs → existing /jobs/search/... backend (transparent)
 * 2. Redirect /jobs/search/... to pretty URL if one exists (canonical)
 * 3. Add X-Robots-Tag for low-priority pages
 */

import { NextRequest, NextResponse } from 'next/server';

const LOCALES = ['en', 'fr', 'de'];

// Pattern: /{locale}/jobs/search/{slug}/all[?params]
const LEGACY_SEARCH_PATTERN = /^\/([a-z]{2})\/jobs\/search\/([^/]+)\/all/;

// Pattern: /{locale}/jobs/{slug}[/{location}][/remote]
const PRETTY_JOB_PATTERN = /^\/([a-z]{2})\/jobs\/([^/]+)(\/[^/]+)?(\/remote)?$/;

// Hub slugs that should NOT be treated as job titles
const HUB_SLUGS = new Set([
  'remote-jobs', 'tech-jobs', 'ai-jobs', 'startup-jobs',
  'teletravail', 'emplois-tech', 'emplois-ia',
  'remote-stellen',
]);

export function middleware(request: NextRequest) {
  const { pathname, searchParams } = request.nextUrl;

  // ── 1. Legacy search URL → redirect to pretty URL ───────────────────────
  const legacyMatch = LEGACY_SEARCH_PATTERN.exec(pathname);
  if (legacyMatch) {
    const [, locale, slug] = legacyMatch;
    if (LOCALES.includes(locale)) {
      // Build pretty URL, preserving location/remote params
      let prettyPath = `/${locale}/jobs/${slug}`;
      const location = searchParams.get('location');
      const remote   = searchParams.get('remote');
      if (location) prettyPath += `/${location}`;
      if (remote === 'true') prettyPath += '/remote';

      const url = request.nextUrl.clone();
      url.pathname = prettyPath;
      url.search   = '';
      return NextResponse.redirect(url, { status: 301 });
    }
  }

  // ── 2. Pretty job URL → rewrite to internal search handler ───────────────
  const prettyMatch = PRETTY_JOB_PATTERN.exec(pathname);
  if (prettyMatch) {
    const [, locale, slug, locationSegment, remoteSegment] = prettyMatch;

    if (!LOCALES.includes(locale) || HUB_SLUGS.has(slug)) {
      return NextResponse.next();
    }

    // SEO page renders at the same pretty URL (Next.js handles it)
    // But we need to inject the internal_url for the SearchPageEmbed.
    // We pass it as a request header so the server component can pick it up.
    let internalUrl = `/jobs/search/${slug}/all`;
    const params: string[] = [];

    const location = locationSegment?.replace('/', '');
    if (location && location !== 'remote') params.push(`location=${location}`);
    if (remoteSegment) params.push('remote=true');
    if (params.length) internalUrl += `?${params.join('&')}`;

    const response = NextResponse.next();
    response.headers.set('x-seo-internal-url', internalUrl);
    response.headers.set('x-seo-locale', locale);
    response.headers.set('x-seo-slug', slug);
    return response;
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/(en|fr|de)/jobs/:path*',
  ],
};
