/**
 * Next.js dynamic SEO page route handler.
 * File: app/[locale]/jobs/[...segments]/page.tsx
 *
 * Handles all programmatic SEO URL patterns:
 *   /{locale}/jobs/{job-title}
 *   /{locale}/jobs/{job-title}/remote
 *   /{locale}/jobs/{job-title}/{location}
 *   /{locale}/jobs/{job-title}/{location}/remote
 *
 * Also handles hub pages:
 *   /{locale}/jobs/remote-jobs
 *   /{locale}/jobs/tech-jobs
 *   etc.
 */

import { Metadata } from 'next';
import { notFound, redirect } from 'next/navigation';

// ─── Types ──────────────────────────────────────────────────────────────────

interface PageContent {
  title_tag: string;
  meta_description: string;
  h1: string;
  intro: string;
  faq: Array<{ question: string; answer: string }>;
  faq_schema: Record<string, unknown>;
}

interface SeoPage {
  pretty_url: string;
  internal_url: string;
  locale: string;
  type: 'core' | 'remote' | 'location' | 'location_remote';
  slug: string;
  location?: string;
  location_label?: string;
  remote: boolean;
  cluster: string;
  seo_score: number;
  alternate_urls: Record<string, string>;
  content: PageContent;
}

// ─── Data loading (cached at build + ISR) ───────────────────────────────────

// In production: import from generated JSON or a Redis/DB lookup
async function getPage(prettyUrl: string): Promise<SeoPage | null> {
  // Option A (static generation): import the JSON directly
  // const urlMap = await import('@/data/url_map.json');
  // const pages  = await import('@/data/rendered_pages.json');
  //
  // Option B (runtime lookup via API route):
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/seo/page?url=${encodeURIComponent(prettyUrl)}`, {
    next: { revalidate: 3600 }, // ISR: revalidate every hour
  });
  if (!res.ok) return null;
  return res.json();
}

// ─── Route params ────────────────────────────────────────────────────────────

interface PageParams {
  locale: string;
  segments: string[];
}

function buildPrettyUrl(locale: string, segments: string[]): string {
  return `/${locale}/jobs/${segments.join('/')}`;
}

// ─── Metadata generation ─────────────────────────────────────────────────────

export async function generateMetadata({ params }: { params: PageParams }): Promise<Metadata> {
  const prettyUrl = buildPrettyUrl(params.locale, params.segments);
  const page = await getPage(prettyUrl);

  if (!page) {
    return { title: 'Jobs | TieTalent' };
  }

  const alternates: Record<string, string> = {};
  for (const [altLocale, altUrl] of Object.entries(page.alternate_urls)) {
    alternates[altLocale] = `${process.env.NEXT_PUBLIC_BASE_URL}${altUrl}`;
  }

  return {
    title:       page.content.title_tag,
    description: page.content.meta_description,
    alternates: {
      canonical: `${process.env.NEXT_PUBLIC_BASE_URL}${prettyUrl}`,
      languages: alternates,
    },
    openGraph: {
      title:       page.content.title_tag,
      description: page.content.meta_description,
      type:        'website',
      url:         `${process.env.NEXT_PUBLIC_BASE_URL}${prettyUrl}`,
    },
  };
}

// ─── Page component ───────────────────────────────────────────────────────────

export default async function SeoJobPage({ params }: { params: PageParams }) {
  const prettyUrl = buildPrettyUrl(params.locale, params.segments);
  const page      = await getPage(prettyUrl);

  if (!page) {
    notFound();
  }

  // Transparently proxy to existing search page
  // (this is handled client-side via SearchPageEmbed component)
  const searchUrl = page.internal_url;

  return (
    <main>
      {/* SEO Header — visible to crawlers and users */}
      <section className="seo-header">
        <h1>{page.content.h1}</h1>
        <p className="seo-intro">{page.content.intro}</p>
      </section>

      {/* Existing search results — injected from internal URL */}
      <SearchPageEmbed internalUrl={searchUrl} />

      {/* FAQ Section with structured data */}
      <section className="faq-section">
        <h2>Frequently Asked Questions</h2>
        {page.content.faq.map((item, i) => (
          <details key={i}>
            <summary>{item.question}</summary>
            <p>{item.answer}</p>
          </details>
        ))}
      </section>

      {/* FAQ structured data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(page.content.faq_schema) }}
      />

      {/* hreflang handled via generateMetadata above */}
    </main>
  );
}

// Placeholder — replace with your actual SearchResults component
function SearchPageEmbed({ internalUrl }: { internalUrl: string }) {
  // This renders the existing /jobs/search/... page inline
  // In practice: pass internalUrl params to your existing JobSearchComponent
  return <div data-search-url={internalUrl} id="job-results-mount" />;
}

// ─── Static generation ────────────────────────────────────────────────────────

// Generate top pages at build time; rest via ISR
export async function generateStaticParams(): Promise<PageParams[]> {
  // Only pre-render high-SEO-score pages at build time (e.g. score ≥ 85)
  // The rest are served via ISR (revalidate: 3600)
  const pages: SeoPage[] = await import('@/data/rendered_pages.json').then(m => m.default) as SeoPage[];

  return pages
    .filter(p => p.seo_score >= 85)
    .map(p => ({
      locale:   p.locale,
      segments: p.pretty_url.replace(`/${p.locale}/jobs/`, '').split('/'),
    }));
}
